import java.util.*;
import java.util.stream.Collectors;
import java.util.Comparator;

/**
 * Clase principal del simulador de la Ruta de la Seda - CICLO 2.
 * Gestiona la creación y manipulación de una ruta comercial con tiendas y robots.
 * Incluye soporte para entrada del problema ICPC y gestión de días/eventos.
 * 
 * @author Santiago Cajamarca
 * @version 3.1 - Ciclo 2 (Requisitos 12 y 13 implementados)
 */
public class SilkRoad {
    
    private SilkPath path;
    private List<Store> stores;
    private List<Robot> robots;
    private boolean isVisible;
    private double totalProfit;
    private double maxPossibleProfit;
    private ProfitProgressBar progressBar;
    private DayManager dayManager;
    private boolean icpcMode;
    
    // Configuración de la barra de progreso
    private static final int PROGRESS_BAR_X = 50;
    private static final int PROGRESS_BAR_Y = 20;
    private static final int PROGRESS_BAR_WIDTH = 300;
    private static final int PROGRESS_BAR_HEIGHT = 25;
    
    /**
     * Constructor de SilkRoad.
     * Inicializa una ruta de seda vacía con barra de progreso.
     */
    public SilkRoad() {
        this.stores = new ArrayList<>();
        this.robots = new ArrayList<>();
        this.isVisible = true;
        this.totalProfit = 0.0;
        this.maxPossibleProfit = 0.0;
        this.dayManager = new DayManager();
        this.icpcMode = false;
        
        // Inicializar la barra de progreso
        this.progressBar = new ProfitProgressBar(
            PROGRESS_BAR_X, PROGRESS_BAR_Y, 
            PROGRESS_BAR_WIDTH, PROGRESS_BAR_HEIGHT
        );
    }
    
    /**
     * Crea una nueva ruta de seda con la longitud especificada (método original).
     * La ruta tomará forma de espiral cuadrada si es necesario.
     * Requisito 1: create (original)
     * 
     * @param length La longitud de la ruta de seda (número de segmentos)
     * @throws IllegalArgumentException si la longitud es menor o igual a 0
     */
    public void create(int length) {
        create(length, null);
    }
    
    /**
     * Crea una nueva ruta de seda con entrada del problema ICPC.
     * EXTENSIÓN - Requisito 10: create con entrada ICPC
     * 
     * @param length La longitud física de la ruta (número de segmentos máximos)
     * @param icpcInput Entrada del problema ICPC (null para modo tradicional)
     * @throws IllegalArgumentException si los parámetros son inválidos
     */
    public void create(int length, String[] icpcInput) {
        if (length <= 0) {
            throw new IllegalArgumentException("La longitud debe ser mayor que 0");
        }
        
        // Limpiar elementos anteriores
        if (path != null) {
            makeInvisible();
            stores.clear();
            robots.clear();
        }
        
        int routeLength = length;
        
        if (icpcInput != null) {
            icpcMode = true;
            routeLength = determineRouteLength(icpcInput, length);
            
            try {
                dayManager.initializeFromICPCInput(icpcInput);
                showMessage("Ruta ICPC inicializada con " + dayManager.getTotalDays() + " días de eventos");
            } catch (Exception e) {
                throw new IllegalArgumentException("Error procesando entrada ICPC: " + e.getMessage());
            }
        } else {
            // Modo tradicional
            icpcMode = false;
            dayManager = new DayManager();
        }
        
        this.path = new SilkPath(routeLength);
        
        totalProfit = 0.0;
        maxPossibleProfit = 0.0;
        updateProgressBar();

        if (isVisible) {
            path.makeVisible();
            progressBar.makeVisible();
        }
        
        showMessage("Ruta creada - Longitud: " + routeLength + 
                   (icpcMode ? " (Modo ICPC)" : " (Modo tradicional)"));
    }
    
    /**
     * Consulta el número de veces que cada tienda ha sido desocupada.
     * NUEVO - Requisito 12: Consultar veces desocupada por tienda
     * Principio de Responsabilidad Única: Delega a cada tienda su propia estadística
     * 
     * @return Mapa con posición de tienda y número de veces desocupada
     */
    public Map<Integer, Integer> consultStoresEmptied() {
        Map<Integer, Integer> storesEmptiedMap = new LinkedHashMap<>();
        
        for (Store store : stores) {
            int position = icpcMode ? store.getOriginalPosition() : store.getPosition();
            storesEmptiedMap.put(position, store.getTimesEmptied());
        }
        
        return storesEmptiedMap;
    }
    
    /**
     * Consulta las ganancias de cada robot en cada movimiento.
     * NUEVO - Requisito 13: Consultar ganancias por movimiento de cada robot
     * Principio de Inversión de Dependencias: Usa abstracción de MovementRecord
     * 
     * @return Mapa con ID del robot y lista de ganancias por movimiento
     */
    public Map<Integer, List<Integer>> consultRobotProfits() {
        Map<Integer, List<Integer>> robotProfitsMap = new LinkedHashMap<>();
        
        for (Robot robot : robots) {
            robotProfitsMap.put(robot.getId(), robot.getMovementProfits());
        }
        
        return robotProfitsMap;
    }
    
    /**
     * Obtiene información detallada sobre las tiendas desocupadas.
     * NUEVO - Requisito 12: Versión detallada con formato legible
     * Principio DRY: Reutiliza consultStoresEmptied()
     * 
     * @return String con información formateada de tiendas desocupadas
     */
    public String getStoresEmptiedInfo() {
        Map<Integer, Integer> storesEmptied = consultStoresEmptied();
        
        if (storesEmptied.isEmpty()) {
            return "No hay tiendas en la ruta.";
        }
        
        StringBuilder info = new StringBuilder();
        info.append("=== Estadísticas de Tiendas Desocupadas ===\n");
        
        int totalTimesEmptied = 0;
        for (Map.Entry<Integer, Integer> entry : storesEmptied.entrySet()) {
            int position = entry.getKey();
            int times = entry.getValue();
            totalTimesEmptied += times;
            
            // Buscar la tienda para obtener más información
            Store store = findStoreByPosition(position);
            if (store != null) {
                info.append(String.format("Tienda en posición %d: ", position));
                info.append(String.format("desocupada %d %s", times, times == 1 ? "vez" : "veces"));
                info.append(String.format(" (Estado: %s)\n", store.isEmpty() ? "Vacía" : "Con tenges"));
            }
        }
        
        info.append(String.format("\nTotal desocupaciones: %d\n", totalTimesEmptied));
        double avgEmptied = stores.isEmpty() ? 0 : (double) totalTimesEmptied / stores.size();
        info.append(String.format("Promedio por tienda: %.2f\n", avgEmptied));
        
        return info.toString();
    }
    
    /**
     * Obtiene información detallada sobre las ganancias de los robots.
     * NUEVO - Requisito 13: Versión detallada con formato legible
     * Principio de Alta Cohesión: Agrupa funcionalidad relacionada
     * 
     * @return String con información formateada de ganancias por robot
     */
    public String getRobotProfitsInfo() {
        Map<Integer, List<Integer>> robotProfits = consultRobotProfits();
        
        if (robotProfits.isEmpty()) {
            return "No hay robots en la ruta.";
        }
        
        StringBuilder info = new StringBuilder();
        info.append("=== Estadísticas de Ganancias por Robot ===\n");
        
        for (Map.Entry<Integer, List<Integer>> entry : robotProfits.entrySet()) {
            int robotId = entry.getKey();
            List<Integer> profits = entry.getValue();
            
            Robot robot = findRobotById(robotId);
            if (robot != null) {
                info.append(String.format("\n--- Robot %d ---\n", robotId));
                info.append(String.format("Posición actual: %d\n", robot.getCurrentPosition()));
                info.append(String.format("Ganancia total: %d\n", robot.getNetProfit()));
                
                if (profits.isEmpty()) {
                    info.append("Sin movimientos registrados\n");
                } else {
                    info.append(String.format("Movimientos realizados: %d\n", profits.size()));
                    info.append("Ganancias por movimiento: ");
                    
                    for (int i = 0; i < profits.size(); i++) {
                        if (i > 0) info.append(", ");
                        info.append(String.format("M%d: %+d", i + 1, profits.get(i)));
                    }
                    info.append("\n");
                    
                    // Estadísticas adicionales
                    int maxProfit = Collections.max(profits);
                    int minProfit = Collections.min(profits);
                    double avgProfit = profits.stream().mapToInt(Integer::intValue).average().orElse(0);
                    
                    info.append(String.format("Mejor movimiento: %+d\n", maxProfit));
                    info.append(String.format("Peor movimiento: %+d\n", minProfit));
                    info.append(String.format("Ganancia promedio: %+.2f\n", avgProfit));
                }
            }
        }
        
        return info.toString();
    }
    
    /**
     * Obtiene un resumen completo del historial de movimientos de todos los robots.
     * NUEVO - Requisito 13: Vista consolidada de movimientos
     * Principio de Abstracción: Proporciona vista de alto nivel
     * 
     * @return String con historial detallado de todos los movimientos
     */
    public String getAllRobotsMovementHistory() {
        if (robots.isEmpty()) {
            return "No hay robots en la ruta.";
        }
        
        StringBuilder history = new StringBuilder();
        history.append("=== Historial Completo de Movimientos ===\n\n");
        
        for (Robot robot : robots) {
            history.append(robot.getMovementSummary()).append("\n");
        }
        
        return history.toString();
    }
    
    /**
     * Resetea todas las estadísticas de tiendas y robots.
     * NUEVO - Requisitos 12 y 13: Reset de estadísticas
     * Principio de Encapsulamiento: Mantiene consistencia interna
     */
    public void resetStatistics() {
        // Resetear estadísticas de tiendas
        for (Store store : stores) {
            store.resetTimesEmptied();
        }
        
        // Resetear historial de movimientos de robots
        for (Robot robot : robots) {
            robot.clearMovementHistory();
        }
        
        showMessage("Estadísticas reseteadas para todas las tiendas y robots");
    }
    
    /**
     * Busca una tienda por su posición.
     * Método auxiliar privado para mantener encapsulamiento
     * 
     * @param position La posición a buscar
     * @return La tienda encontrada o null
     */
    private Store findStoreByPosition(int position) {
        for (Store store : stores) {
            int storePos = icpcMode ? store.getOriginalPosition() : store.getPosition();
            if (storePos == position) {
                return store;
            }
        }
        return null;
    }
    
    /**
     * Busca un robot por su ID.
     * Método auxiliar privado para mantener encapsulamiento
     * 
     * @param robotId El ID del robot
     * @return El robot encontrado o null
     */
    private Robot findRobotById(int robotId) {
        for (Robot robot : robots) {
            if (robot.getId() == robotId) {
                return robot;
            }
        }
        return null;
    }
    
    /**
     * Mueve todos los robots de forma optimizada para maximizar ganancias.
     * Requisito 11: Movimientos optimizados
     * 
     * @return Resultado de la optimización con detalles de movimientos
     */
    public RobotMovementOptimizer.OptimizationResult optimizeRobotMovements() {
        if (path == null) {
            showMessage("Error: La ruta no ha sido creada aún");
            return new RobotMovementOptimizer.OptimizationResult(new ArrayList<>(), "Ruta no creada");
        }
        
        if (robots.isEmpty()) {
            showMessage("No hay robots para mover");
            return new RobotMovementOptimizer.OptimizationResult(new ArrayList<>(), "Sin robots");
        }
        
        // Aplicar algoritmo de optimización
        RobotMovementOptimizer.OptimizationResult result = 
            RobotMovementOptimizer.optimizeMovements(robots, stores, path.getLength(), icpcMode);
        
        if (result.getAssignments().isEmpty()) {
            showMessage("No se encontraron movimientos rentables");
            return result;
        }
        
        showMessage("=== Iniciando Optimización de Movimientos ===");
        showMessage("Estrategia: " + result.getStrategy());
        showMessage("Asignaciones encontradas: " + result.getAssignments().size());
        
        // Ejecutar los movimientos optimizados
        double profitBefore = totalProfit;
        int successfulMoves = 0;
        
        for (RobotMovementOptimizer.RobotStoreAssignment assignment : result.getAssignments()) {
            Robot robot = assignment.getRobot();
            Store targetStore = assignment.getStore();
            int targetPosition = icpcMode ? 
                mapICPCPositionToRoute(targetStore.getOriginalPosition()) : 
                targetStore.getPosition();
            
            // Calcular pasos necesarios
            int currentPos = robot.getCurrentPosition();
            int steps = targetPosition - currentPos;
            
            // Ejecutar el movimiento optimizado
            if (moveRobot(robot.getId(), steps)) {
                successfulMoves++;
                showMessage(String.format("✓ Robot %d → Pos %d (ganancia estimada: %d)", 
                    robot.getId(), targetPosition, assignment.getProfit()));
            } else {
                showMessage(String.format("✗ Fallo moviendo Robot %d → Pos %d", 
                    robot.getId(), targetPosition));
            }
        }
        
        double profitGained = totalProfit - profitBefore;
        
        showMessage("=== Resultado de Optimización ===");
        showMessage("Movimientos exitosos: " + successfulMoves + "/" + result.getAssignments().size());
        showMessage("Ganancia obtenida: " + profitGained);
        showMessage("Ganancia esperada: " + result.getTotalProfit());
        showMessage("Eficiencia: " + String.format("%.1f%%", 
            result.getTotalProfit() > 0 ? (profitGained / result.getTotalProfit()) * 100 : 0));
        
        // Actualizar el robot con mayor ganancia para que parpadee
        updateHighestProfitRobot();
        
        return result;
    }
    
    /**
     * Método auxiliar para actualizar el robot con mayor ganancia.
     * Implementa el requisito de usabilidad de parpadeo.
     * Requisito de usabilidad: robot con mayor ganancia parpadea
     */
    private void updateHighestProfitRobot() {
        if (robots.isEmpty()) return;
        
        for (Robot robot : robots) {
            robot.stopBlinking();
        }
        
        Robot highestProfitRobot = robots.stream()
            .max(Comparator.comparingInt(Robot::getNetProfit))
            .orElse(null);
        
        if (highestProfitRobot != null && highestProfitRobot.getNetProfit() > 0) {
            highestProfitRobot.startBlinking();
            showMessage("Robot " + highestProfitRobot.getId() + 
                       " tiene la mayor ganancia (" + highestProfitRobot.getNetProfit() + 
                       ") y está parpadeando");
        }
    }
    
    /**
     * Determina la longitud necesaria de la ruta basándose en las posiciones del ICPC.
     * Mapea las posiciones del ICPC a índices de la ruta espiral.
     * 
     * @param icpcInput Entrada del problema ICPC
     * @param suggestedLength Longitud sugerida
     * @return Longitud calculada para la ruta
     */
    private int determineRouteLength(String[] icpcInput, int suggestedLength) {
        if (icpcInput == null || icpcInput.length == 0) {
            return suggestedLength;
        }
        
        Set<Integer> positions = new HashSet<>();
        
        try {
            int n = Integer.parseInt(icpcInput[0]);
            
            for (int i = 1; i <= n; i++) {
                String[] parts = icpcInput[i].trim().split("\\s+");
                if (parts.length >= 2) {
                    int position = Integer.parseInt(parts[1]);
                    positions.add(position);
                }
            }
            
            if (!positions.isEmpty()) {
                int maxPos = Collections.max(positions);
                int minPos = Collections.min(positions);
                int range = maxPos - minPos + 1;

                return Math.max(range, suggestedLength);
            }
            
        } catch (Exception e) {
            showMessage("Error calculando longitud de ruta: " + e.getMessage());
        }
        
        return suggestedLength;
    }
    
    /**
     * Ejecuta el siguiente día en la secuencia ICPC.
     * Requisito 10: Ejecución por días
     * 
     * @return true si se ejecutó exitosamente, false si no hay más días
     * @throws IllegalStateException si no está en modo ICPC
     */
    public boolean executeNextDay() {
        if (!icpcMode) {
            throw new IllegalStateException("executeNextDay() solo disponible en modo ICPC");
        }
        
        if (!dayManager.hasMoreDays()) {
            showMessage("No hay más días por ejecutar");
            return false;
        }
        
        int dayNumber = dayManager.getCurrentDay();
        showMessage("Ejecutando día " + (dayNumber + 1) + "...");
        
        boolean success = dayManager.executeNextDay(this);
        
        if (success) {
            showMessage("Día " + (dayNumber + 1) + " ejecutado exitosamente");
            showMessage("Ganancia actual: " + totalProfit);
        } else {
            showMessage("Error ejecutando día " + (dayNumber + 1));
        }
        
        return success;
    }
    
    /**
     * Ejecuta todos los días restantes en la secuencia ICPC.
     * Requisito 10: Ejecución completa
     * 
     * @return El número de días ejecutados exitosamente
     * @throws IllegalStateException si no está en modo ICPC
     */
    public int executeAllDays() {
        if (!icpcMode) {
            throw new IllegalStateException("executeAllDays() solo disponible en modo ICPC");
        }
        
        int successfulDays = dayManager.executeAllDays(this);
        showMessage("Ejecutados " + successfulDays + " de " + dayManager.getTotalDays() + " días");
        
        return successfulDays;
    }
    
    /**
     * Obtiene información sobre el estado de los días ICPC.
     * Requisito 10: Consulta de estado
     * 
     * @return String con información de los días
     */
    public String getDaysInfo() {
        if (!icpcMode) {
            return "No está en modo ICPC";
        }
        
        StringBuilder info = new StringBuilder();
        info.append("=== Información de Días ICPC ===\n");
        info.append("Días totales: ").append(dayManager.getTotalDays()).append("\n");
        info.append("Día actual: ").append(dayManager.getCurrentDay() + 1).append("\n");
        info.append("Días restantes: ").append(dayManager.getTotalDays() - dayManager.getCurrentDay()).append("\n");
        
        if (dayManager.hasMoreDays()) {
            info.append("Estado: En progreso\n");
        } else {
            info.append("Estado: Completado\n");
        }
        
        return info.toString();
    }
    
    /**
     * Reinicia la secuencia de días al inicio.
     * NUEVO - Requisito 10: Reset de secuencia
     */
    public void resetDaySequence() {
        if (icpcMode) {
            dayManager.reset();
            showMessage("Secuencia de días reiniciada");
        }
    }
    
    /**
     * Mapea una posición del problema ICPC a un índice de la ruta espiral.
     * Permite manejar posiciones arbitrarias del ICPC en nuestra ruta fija.
     * 
     * @param icpcPosition Posición del problema ICPC
     * @return Índice mapeado en la ruta espiral
     */
    private int mapICPCPositionToRoute(int icpcPosition) {
        if (path == null) {
            return 0;
        }
        return Math.abs(icpcPosition) % path.getLength();
    }
    
    /**
     * Añade una tienda con soporte para posiciones ICPC.
     * EXTENSIÓN del método original para soportar mapeo de posiciones
     * 
     * @param position La posición donde ubicar la tienda (ICPC o tradicional)
     * @param tenges La cantidad inicial de tenges en la tienda
     * @return true si se pudo añadir la tienda, false en caso contrario
     */
    public boolean addStore(int position, int tenges) {
        int mappedPosition = icpcMode ? mapICPCPositionToRoute(position) : position;
        
        if (path == null) {
            showMessage("Error: La ruta no ha sido creada aún");
            return false;
        }
        
        if (mappedPosition < 0 || mappedPosition >= path.getLength()) {
            showMessage("Error: Posición fuera de los límites de la ruta");
            return false;
        }
        
        // Verifica si la posición está ocupada por una tienda
        for (Store store : stores) {
            int storePos = icpcMode ? mapICPCPositionToRoute(store.getOriginalPosition()) : store.getPosition();
            if (storePos == mappedPosition) {
                showMessage("Error: Ya existe una tienda en la posición " + position);
                return false;
            }
        }
        
        // Verifica si hay un robot con posición inicial ahí
        for (Robot robot : robots) {
            int robotPos = icpcMode ? mapICPCPositionToRoute(robot.getOriginalInitialPosition()) : robot.getInitialPosition();
            if (robotPos == mappedPosition) {
                showMessage("Error: Hay un robot con posición inicial en " + position);
                return false;
            }
        }
        
        // Crea y añade la tienda
        Store newStore = new Store(mappedPosition, tenges);
        if (icpcMode) {
            newStore.setOriginalPosition(position); 
        }
        stores.add(newStore);
        
        PathSegment segment = path.getSegment(mappedPosition);
        int[] visualCoords = segment.getCenteredCoordinates();
        newStore.setPosition(visualCoords[0], visualCoords[1]);
        
        if (isVisible) {
            newStore.makeVisible();
        }
        
        // Actualiza la ganancia máxima posible
        maxPossibleProfit += tenges;
        updateProgressBar();
        
        String positionStr = icpcMode ? position + " (mapeada a " + mappedPosition + ")" : String.valueOf(position);
        showMessage("Tienda añadida en posición " + positionStr + " con " + tenges + " tenges");
        return true;
    }
    
    /**
     * Añade un robot con soporte para posiciones ICPC.
     * EXTENSIÓN del método original para soportar mapeo de posiciones
     * 
     * @param initialPosition La posición inicial del robot (ICPC o tradicional)
     * @return El ID del robot creado, o -1 si no se pudo crear
     */
    public int addRobot(int initialPosition) {
        int mappedPosition = icpcMode ? mapICPCPositionToRoute(initialPosition) : initialPosition;
        
        if (path == null) {
            showMessage("Error: La ruta no ha sido creada aún");
            return -1;
        }
        
        if (mappedPosition < 0 || mappedPosition >= path.getLength()) {
            showMessage("Error: Posición fuera de los límites de la ruta");
            return -1;
        }
        
        // Verifica si ya hay un robot con esa posición inicial
        for (Robot robot : robots) {
            int robotPos = icpcMode ? mapICPCPositionToRoute(robot.getOriginalInitialPosition()) : robot.getInitialPosition();
            if (robotPos == mappedPosition) {
                showMessage("Error: Ya existe un robot con posición inicial en " + initialPosition);
                return -1;
            }
        }
        
        // Verifica si hay una tienda en esa posición
        for (Store store : stores) {
            int storePos = icpcMode ? mapICPCPositionToRoute(store.getOriginalPosition()) : store.getPosition();
            if (storePos == mappedPosition) {
                showMessage("Error: Hay una tienda en la posición " + initialPosition);
                return -1;
            }
        }
        
        // Crear y añadir el robot
        Robot newRobot = new Robot(mappedPosition, 1000);
        if (icpcMode) {
            newRobot.setOriginalInitialPosition(initialPosition);
        }
        robots.add(newRobot);
        
        // Posicionar visualmente el robot
        PathSegment segment = path.getSegment(mappedPosition);
        int[] visualCoords = segment.getCenteredCoordinates();
        newRobot.setVisualPosition(visualCoords[0] + 5, visualCoords[1] - 5);
        
        if (isVisible) {
            newRobot.makeVisible();
        }
        
        String positionStr = icpcMode ? initialPosition + " (mapeada a " + mappedPosition + ")" : String.valueOf(initialPosition);
        showMessage("Robot añadido con ID " + newRobot.getId() + " en posición " + positionStr);
        return newRobot.getId();
    }
    
    /**
     * Elimina una tienda de la posición especificada.
     * Requisito 2: remove store
     */
    public boolean removeStore(int position) {
        int mappedPosition = icpcMode ? mapICPCPositionToRoute(position) : position;
        Store storeToRemove = null;
        
        for (Store store : stores) {
            int storePos = icpcMode ? mapICPCPositionToRoute(store.getOriginalPosition()) : store.getPosition();
            if (storePos == mappedPosition) {
                storeToRemove = store;
                break;
            }
        }
        
        if (storeToRemove != null) {
            storeToRemove.makeInvisible();
            stores.remove(storeToRemove);
            maxPossibleProfit -= storeToRemove.getInitialTenges();
            updateProgressBar();
            showMessage("Tienda eliminada de la posición " + position);
            return true;
        }
        
        showMessage("Error: No hay tienda en la posición " + position);
        return false;
    }
    
    /**
     * Reabastece todas las tiendas con su inventario inicial.
     * Requisito 2: resupply stores
     */
    public void resupplyStores() {
        for (Store store : stores) {
            store.resupply();
            if (isVisible) {
                store.makeVisible();
            }
        }
        
        recalculateMaxProfit();
        updateProgressBar();
        showMessage("Todas las tiendas han sido reabastecidas");
    }
    
    /**
     * Elimina un robot específico.
     * Requisito 3: delete robot
     */
    public boolean deleteRobot(int robotId) {
        Robot robotToRemove = null;
        
        for (Robot robot : robots) {
            if (robot.getId() == robotId) {
                robotToRemove = robot;
                break;
            }
        }
        
        if (robotToRemove != null) {
            robotToRemove.makeInvisible();
            robots.remove(robotToRemove);
            recalculateTotalProfit();
            updateProgressBar();
            showMessage("Robot " + robotId + " eliminado");
            return true;
        }
        
        showMessage("Error: No se encontró robot con ID " + robotId);
        return false;
    }
    
    /**
     * Retorna todos los robots a sus posiciones iniciales.
     * Requisito 3: return robots
     */
    public void returnRobots() {
        for (Robot robot : robots) {
            robot.returnToInitialPosition();
            robot.setCostIncurred(0);
            robot.resetTengesCollected();
            
            int visualPosition = icpcMode ? mapICPCPositionToRoute(robot.getOriginalInitialPosition()) : robot.getInitialPosition();
            PathSegment segment = path.getSegment(visualPosition);
            int[] visualCoords = segment.getCenteredCoordinates();
            robot.setVisualPosition(visualCoords[0] + 5, visualCoords[1] - 5);
        }
        
        recalculateTotalProfit();
        updateProgressBar();
        showMessage("Todos los robots han sido retornados a sus posiciones iniciales");
    }
    
    /**
     * Mueve un robot específico.
     * Requisito 4: move robot
     * MODIFICADO - Ciclo 2: Registra movimientos con ganancias (Requisito 13)
     */
    public boolean moveRobot(int robotId, int steps) {
        Robot robot = null;
        
        for (Robot r : robots) {
            if (r.getId() == robotId) {
                robot = r;
                break;
            }
        }
        
        if (robot == null) {
            showMessage("Error: No se encontró robot con ID " + robotId);
            return false;
        }
        
        int currentPos = robot.getCurrentPosition();
        int newPos = currentPos + steps;
        
        if (newPos < 0) {
            newPos = 0;
            steps = newPos - currentPos;
        } else if (newPos >= path.getLength()) {
            newPos = path.getLength() - 1;
            steps = newPos - currentPos;
        }
        
        int movementCost = Math.abs(steps);
        robot.addCost(movementCost);
        
        // Verificar si hay tienda en la nueva posición
        int tengesCollected = 0;
        for (Store store : stores) {
            int storePos = icpcMode ? mapICPCPositionToRoute(store.getOriginalPosition()) : store.getPosition();
            if (storePos == newPos && store.getTenges() > 0) {
                tengesCollected = store.collectAll();
                robot.collectTenges(tengesCollected);
                break;
            }
        }
        
        // Registrar el movimiento con información de ganancias (Requisito 13)
        robot.moveTo(newPos, Math.abs(steps), movementCost, tengesCollected);
        
        // Actualizar posición visual
        PathSegment segment = path.getSegment(newPos);
        int[] visualCoords = segment.getCenteredCoordinates();
        robot.setVisualPosition(visualCoords[0] + 5, visualCoords[1] - 5);
        
        // Calcular ganancia neta
        int netProfit = tengesCollected - movementCost;
        totalProfit += netProfit;
        updateProgressBar();
        
        if (tengesCollected > 0) {
            showMessage("Robot " + robotId + " recogió " + tengesCollected + 
                       " tenges en posición " + newPos + 
                       ". Costo: " + movementCost + 
                       ", Ganancia neta: " + netProfit);
        } else {
            showMessage("Robot " + robotId + " se movió a posición " + newPos + 
                       ". Costo: " + movementCost);
        }
        
        // Actualizar robot con mayor ganancia
        updateHighestProfitRobot();
        
        return true;
    }
    
    /**
     * Reinicia la ruta de seda.
     * Requisito 5: reboot
     */
    public void reboot() {
        resupplyStores();
        returnRobots();
        totalProfit = 0.0;
        recalculateMaxProfit();
        updateProgressBar();
        showMessage("Simulador reiniciado (reboot)");
    }
    
    /**
     * Consulta las ganancias obtenidas.
     * Requisito 6: consult profit
     */
    public double getProfit() {
        return totalProfit;
    }
    
    /**
     * Consulta la información de la ruta de seda.
     * Requisito 7: consult silk road
     * MODIFICADO - Ciclo 2: Incluye estadísticas de requisitos 12 y 13
     */
    public String getInfo() {
        StringBuilder info = new StringBuilder();
        info.append("=== Información de la Ruta de Seda ===\n");
        
        if (path != null) {
            info.append("Modo: ").append(icpcMode ? "ICPC" : "Tradicional").append("\n");
            info.append("Longitud de la ruta: ").append(path.getLength()).append(" segmentos\n");
            
            if (icpcMode) {
                info.append(getDaysInfo()).append("\n");
            }
            
            info.append("Número de tiendas: ").append(stores.size()).append("\n");
            
            for (Store store : stores) {
                String posStr = icpcMode ? 
                    store.getOriginalPosition() + " (→" + store.getPosition() + ")" : 
                    String.valueOf(store.getPosition());
                info.append("  - Tienda en pos ").append(posStr)
                    .append(": ").append(store.getTenges()).append("/")
                    .append(store.getInitialTenges()).append(" tenges")
                    .append(" (desocupada ").append(store.getTimesEmptied())
                    .append(" veces)\n");
            }
            
            info.append("Número de robots: ").append(robots.size()).append("\n");
            
            for (Robot robot : robots) {
                info.append("  - ").append(robot.getInfo()).append("\n");
            }
            
            info.append("Ganancia actual: ").append(totalProfit).append("\n");
            info.append("Ganancia máxima posible: ").append(maxPossibleProfit).append("\n");
            info.append(progressBar.getStatusInfo()).append("\n");
        } else {
            info.append("La ruta no ha sido creada aún.\n");
        }
        
        return info.toString();
    }
    
    /**
     * Hace visible el simulador.
     * Requisito 8: make visible
     */
    public void makeVisible() {
        isVisible = true;
        
        if (path != null) {
            path.makeVisible();
            progressBar.makeVisible();
            
            for (Store store : stores) {
                store.makeVisible();
            }
            
            for (Robot robot : robots) {
                robot.makeVisible();
                // Si el robot debe parpadear, reiniciar el parpadeo
                if (robot.getNetProfit() > 0) {
                    updateHighestProfitRobot();
                }
            }
        }
    }
    
    /**
     * Hace invisible el simulador.
     * Requisito 8: make invisible
     */
    public void makeInvisible() {
        isVisible = false;
        
        if (path != null) {
            path.makeInvisible();
            progressBar.makeInvisible();
            
            for (Store store : stores) {
                store.makeInvisible();
            }
            
            for (Robot robot : robots) {
                robot.stopBlinking();
                robot.makeInvisible();
            }
        }
    }
    
    /**
     * Termina el simulador.
     * Requisito 9: finish
     */
    public void finish() {
        makeInvisible();
        stores.clear();
        robots.clear();
        path = null;
        totalProfit = 0.0;
        maxPossibleProfit = 0.0;
        dayManager = new DayManager();
        icpcMode = false;
        showMessage("Simulador terminado");
    }
    
    /**
     * Verifica si el simulador está visible.
     */
    public boolean isVisible() {
        return isVisible;
    }
    
    /**
     * Verifica si está en modo ICPC.
     * NUEVO - Requisito 10
     */
    public boolean isICPCMode() {
        return icpcMode;
    }
    
    // Métodos auxiliares privados
    
    private void updateProgressBar() {
        if (progressBar != null) {
            progressBar.updateProgress(totalProfit, maxPossibleProfit);
        }
    }
    
    private void recalculateMaxProfit() {
        maxPossibleProfit = 0.0;
        for (Store store : stores) {
            maxPossibleProfit += store.getInitialTenges();
        }
    }
    
    private void recalculateTotalProfit() {
        totalProfit = 0.0;
        for (Robot robot : robots) {
            totalProfit += robot.getNetProfit();
        }
    }
    
    public ProfitProgressBar getProgressBar() {
        return progressBar;
    }
    
    public void setProgressBarPosition(int x, int y) {
        if (progressBar != null) {
            progressBar.setPosition(x, y);
        }
    }
    
    public double getProgressPercentage() {
        return progressBar != null ? progressBar.getProgressPercentage() : 0.0;
    }
    
    private void showMessage(String message) {
        if (isVisible) {
            System.out.println("[SilkRoad] " + message);
        }
    }
    
    // Getters para acceso a las listas (solo lectura)
    
    /**
     * Obtiene una copia inmutable de la lista de tiendas.
     * Principio de Encapsulamiento: No expone la lista interna
     * 
     * @return Lista inmutable de tiendas
     */
    public List<Store> getStores() {
        return Collections.unmodifiableList(stores);
    }
    
    /**
     * Obtiene una copia inmutable de la lista de robots.
     * Principio de Encapsulamiento: No expone la lista interna
     * 
     * @return Lista inmutable de robots
     */
    public List<Robot> getRobots() {
        return Collections.unmodifiableList(robots);
    }
}