package Solver;

import Simulator.SilkRoad;
import java.util.*;

/**
 * Resuelve el problema de la maratón ICPC 2024 - The Silk Road with Robots.
 * Incluye capacidad de simulación visual con control de velocidad.
 * 
 * Principios SOLID aplicados:
 * - Single Responsibility: Métodos específicos para cada tarea
 * - Open/Closed: Extensible para nuevas estrategias de input
 * - Dependency Inversion: Usa abstracciones (Scanner, interfaces)
 * 
 * Prácticas XP:
 * - Simplicidad: Código claro y directo
 * - Refactoring: Métodos pequeños y reutilizables
 * - Testing: Validación de inputs
 * 
 * @author Santiago Cajamarca
 * @version 3.0 - Con input del usuario
 */
public class SilkRoadContest {
    
    /**
     * Representa un robot en el problema.
     */
    private static class ContestRobot {
        int id;
        long position;
        
        public ContestRobot(int id, long position) {
            this.id = id;
            this.position = position;
        }
    }
    
    /**
     * Representa una tienda en el problema.
     */
    private static class ContestStore {
        int id;
        long position;
        long tenges;
        
        public ContestStore(int id, long position, long tenges) {
            this.id = id;
            this.position = position;
            this.tenges = tenges;
        }
    }
    
    /**
     * Representa una asignación robot-tienda con su ganancia.
     */
    private static class Assignment implements Comparable<Assignment> {
        ContestRobot robot;
        ContestStore store;
        long distance;
        long profit;
        
        public Assignment(ContestRobot robot, ContestStore store) {
            this.robot = robot;
            this.store = store;
            this.distance = Math.abs(robot.position - store.position);
            this.profit = store.tenges - distance;
        }
        
        @Override
        public int compareTo(Assignment other) {
            return Long.compare(other.profit, this.profit);
        }
    }
    
    /**
     * Resultado de la solución para un día.
     */
    public static class DaySolution {
        int day;
        long maxProfit;
        List<Assignment> assignments;
        
        public DaySolution(int day, long maxProfit, List<Assignment> assignments) {
            this.day = day;
            this.maxProfit = maxProfit;
            this.assignments = new ArrayList<>(assignments);
        }
        
        public long getMaxProfit() {
            return maxProfit;
        }
        
        public List<Assignment> getAssignments() {
            return new ArrayList<>(assignments);
        }
    }
    
    // Estado del problema
    private List<ContestRobot> robots;
    private List<ContestStore> stores;
    private List<DaySolution> solutions;
    private String[] lastInput;
    private Scanner scanner;
    
    /**
     * Constructor del solver.
     * Principio: Single Responsibility - inicialización simple
     */
    public SilkRoadContest() {
        this.robots = new ArrayList<>();
        this.stores = new ArrayList<>();
        this.solutions = new ArrayList<>();
        this.scanner = new Scanner(System.in);
    }
    
    /**
     * Resuelve el problema pidiendo input al usuario.
     * Muestra solo resultados en consola sin visualización.
     * 
     * Principio: Single Responsibility - solo resolver y mostrar resultados
     */
    public void solve() {
        System.out.println("=== SOLVER SILK ROAD ICPC 2024 ===\n");
        
        int[][] days = readInputFromUser();
        if (days == null) return;
        
        int[] results = solveInternal(days);
        displayResults(results);
    }
    
    /**
     * Simula visualmente el problema pidiendo input al usuario.
     * Permite elegir velocidad de simulación.
     * 
     * Principio: Single Responsibility - solo simular visualmente
     * XP: Simplicidad - parámetros claros
     */
    public void simulate() {
        System.out.println("=== SIMULACIÓN SILK ROAD ICPC 2024 ===\n");
        
        int[][] days = readInputFromUser();
        if (days == null) return;
        
        boolean slow = askSimulationSpeed();
        simulateInternal(days, slow);
    }
    
    /**
     * Lee el input del usuario desde consola.
     * 
     * Formato esperado:
     * - Primera línea: número de días (n)
     * - Siguientes n líneas: tipo posición [tenges]
     * 
     * Principio: Single Responsibility - solo lectura de input
     * XP: Refactoring - método reutilizable
     * 
     * @return Array de días con eventos, o null si hay error
     */
    private int[][] readInputFromUser() {
        try {
            System.out.println("Ingrese el número de días:");
            int n = scanner.nextInt();
            scanner.nextLine(); // Consumir salto de línea
            
            if (n <= 0) {
                System.out.println("Error: El número de días debe ser mayor a 0");
                return null;
            }
            
            int[][] days = new int[n][];
            
            System.out.println("\nIngrese los eventos (uno por línea):");
            System.out.println("Formato robot: 1 posición");
            System.out.println("Formato tienda: 2 posición tenges\n");
            
            for (int i = 0; i < n; i++) {
                System.out.print("Día " + (i + 1) + ": ");
                String line = scanner.nextLine().trim();
                
                if (line.isEmpty()) {
                    System.out.println("Error: Línea vacía");
                    return null;
                }
                
                days[i] = parseLine(line);
                if (days[i] == null) {
                    System.out.println("Error: Formato inválido en día " + (i + 1));
                    return null;
                }
            }
            
            return days;
            
        } catch (InputMismatchException e) {
            System.out.println("Error: Debe ingresar un número válido");
            scanner.nextLine(); // Limpiar buffer
            return null;
        } catch (Exception e) {
            System.out.println("Error leyendo input: " + e.getMessage());
            return null;
        }
    }
    
    /**
     * Parsea una línea de input.
     * 
     * Principio: Single Responsibility - solo parsear una línea
     * XP: Simplicidad - lógica clara
     * 
     * @param line Línea de texto a parsear
     * @return Array con [tipo, posición] o [tipo, posición, tenges]
     */
    private int[] parseLine(String line) {
        try {
            String[] parts = line.split("\\s+");
            
            if (parts.length < 2) {
                return null;
            }
            
            int type = Integer.parseInt(parts[0]);
            int position = Integer.parseInt(parts[1]);
            
            if (type == 1) {
                // Robot
                return new int[]{type, position};
            } else if (type == 2) {
                // Tienda
                if (parts.length < 3) {
                    return null;
                }
                int tenges = Integer.parseInt(parts[2]);
                return new int[]{type, position, tenges};
            } else {
                return null;
            }
            
        } catch (NumberFormatException e) {
            return null;
        }
    }
    
    /**
     * Pregunta al usuario la velocidad de simulación.
     * 
     * Principio: Single Responsibility - solo obtener preferencia de velocidad
     * XP: Simplicidad - pregunta directa
     * 
     * @return true si modo lento, false si modo rápido
     */
    private boolean askSimulationSpeed() {
        System.out.println("\n¿Velocidad de simulación?");
        System.out.println("1. Lenta (recomendada para ver detalles)");
        System.out.println("2. Rápida");
        System.out.print("Opción (1/2): ");
        
        try {
            int option = scanner.nextInt();
            scanner.nextLine(); // Consumir salto de línea
            return option == 1;
        } catch (Exception e) {
            System.out.println("Opción inválida, usando velocidad lenta por defecto");
            scanner.nextLine(); // Limpiar buffer
            return true;
        }
    }
    
    /**
     * Resuelve el problema internamente.
     * 
     * Principio: Single Responsibility - solo resolver algoritmo
     * 
     * @param days Eventos por día
     * @return Array con ganancias por día
     */
    private int[] solveInternal(int[][] days) {
        // Limpiar estado previo
        robots.clear();
        stores.clear();
        solutions.clear();
        
        // Convertir a formato String[] para procesamiento interno
        String[] input = new String[days.length + 1];
        input[0] = String.valueOf(days.length);
        
        for (int i = 0; i < days.length; i++) {
            if (days[i].length == 2) {
                input[i + 1] = days[i][0] + " " + days[i][1];
            } else {
                input[i + 1] = days[i][0] + " " + days[i][1] + " " + days[i][2];
            }
        }
        
        lastInput = input;
        
        // Procesar cada día
        int[] results = new int[days.length];
        
        for (int day = 0; day < days.length; day++) {
            // Añadir elemento del día
            int type = days[day][0];
            long position = days[day][1];
            
            if (type == 1) {
                robots.add(new ContestRobot(robots.size() + 1, position));
            } else {
                long tenges = days[day][2];
                stores.add(new ContestStore(stores.size() + 1, position, tenges));
            }
            
            // Calcular ganancia
            DaySolution solution = calculateMaxProfit(day + 1);
            solutions.add(solution);
            results[day] = (int) solution.maxProfit;
        }
        
        return results;
    }
    
    /**
     * Calcula la máxima ganancia para un día.
     * Algoritmo greedy optimizado que maximiza asignaciones robot-tienda.
     * 
     * Principio: Single Responsibility - solo calcular ganancia óptima
     * 
     * Estrategia:
     * 1. Ordena todas las asignaciones posibles por ganancia
     * 2. Selecciona greedily evitando conflictos (una tienda por robot, una tienda puede ser visitada solo una vez)
     * 3. Maximiza el número de robots que se mueven rentablemente
     * 
     * @param day Número del día
     * @return Solución con ganancia y asignaciones
     */
    private DaySolution calculateMaxProfit(int day) {
        if (robots.isEmpty() || stores.isEmpty()) {
            return new DaySolution(day, 0, new ArrayList<>());
        }
        
        // Generar todas las asignaciones posibles con ganancia positiva
        List<Assignment> allAssignments = new ArrayList<>();
        
        for (ContestRobot robot : robots) {
            for (ContestStore store : stores) {
                Assignment assignment = new Assignment(robot, store);
                if (assignment.profit > 0) {
                    allAssignments.add(assignment);
                }
            }
        }
        
        if (allAssignments.isEmpty()) {
            return new DaySolution(day, 0, new ArrayList<>());
        }
        
        // Ordenar por ganancia descendente
        Collections.sort(allAssignments);
        
        // Selección greedy: cada tienda solo puede ser visitada una vez
        // y cada robot solo puede ir a una tienda
        Set<Integer> usedStores = new HashSet<>();
        Set<Integer> usedRobots = new HashSet<>();
        List<Assignment> selectedAssignments = new ArrayList<>();
        long totalProfit = 0;
        
        for (Assignment assignment : allAssignments) {
            // Verificar que ni el robot ni la tienda hayan sido asignados
            if (!usedRobots.contains(assignment.robot.id) && 
                !usedStores.contains(assignment.store.id)) {
                
                selectedAssignments.add(assignment);
                usedRobots.add(assignment.robot.id);
                usedStores.add(assignment.store.id);
                totalProfit += assignment.profit;
            }
            
            // Optimización: si todos los robots o todas las tiendas fueron asignados, terminar
            if (usedRobots.size() == robots.size() || usedStores.size() == stores.size()) {
                break;
            }
        }
        
        return new DaySolution(day, totalProfit, selectedAssignments);
    }
    
    /**
     * Muestra los resultados en consola.
     * 
     * Principio: Single Responsibility - solo mostrar resultados
     * XP: Simplicidad - formato claro
     * 
     * @param results Array con ganancias por día
     */
    private void displayResults(int[] results) {
        System.out.println("\n=== RESULTADOS ===\n");
        
        System.out.print("Ganancias por día: [");
        for (int i = 0; i < results.length; i++) {
            System.out.print(results[i]);
            if (i < results.length - 1) System.out.print(", ");
        }
        System.out.println("]\n");
        
        long totalProfit = 0;
        System.out.println("Detalle:");
        for (int i = 0; i < solutions.size(); i++) {
            DaySolution sol = solutions.get(i);
            totalProfit += sol.maxProfit;
            System.out.println("Día " + (i + 1) + ": ganancia = " + sol.maxProfit + 
                             " (" + sol.assignments.size() + " movimientos)");
        }
        
        System.out.println("\nGanancia total acumulada: " + totalProfit);
    }
    
    /**
     * Simula visualmente la solución.
     * 
     * Principio: Single Responsibility - solo simulación visual
     * 
     * @param days Eventos por día
     * @param slow Velocidad de simulación
     */
    private void simulateInternal(int[][] days, boolean slow) {
        // Resolver primero si no se ha hecho
        if (solutions.isEmpty()) {
            solveInternal(days);
        }
        
        int delayBetweenDays = slow ? 2000 : 800;
        int delayBetweenMoves = slow ? 1000 : 400;
        
        try {
            long maxPos = determineLongestDistance();
            int routeLength = (int) Math.min(maxPos + 20, 200);
            
            SilkRoad simulator = new SilkRoad(routeLength);
            simulator.makeVisible();
            
            System.out.println("=== SIMULACIÓN SILK ROAD ICPC 2024 ===");
            System.out.println("Modo: " + (slow ? "LENTO" : "RÁPIDO"));
            System.out.println("Longitud de ruta: " + routeLength + " segmentos\n");
            
            Map<Integer, Integer> robotIdMap = new HashMap<>();
            int robotsAdded = 0;
            int storesAdded = 0;
            
            for (int dayIdx = 0; dayIdx < solutions.size(); dayIdx++) {
                DaySolution solution = solutions.get(dayIdx);
                int dayNumber = solution.day;
                
                System.out.println("\n--- DÍA " + dayNumber + " ---");
                
                if (dayNumber > 1) {
                    System.out.println("Reboot: reabasteciendo tiendas y retornando robots");
                    simulator.reboot();
                    Thread.sleep(delayBetweenDays / 2);
                }
                
                String[] parts = lastInput[dayNumber].trim().split("\\s+");
                int type = Integer.parseInt(parts[0]);
                int position = Integer.parseInt(parts[1]);
                int mappedPosition = mapPosition(position, routeLength);
                
                if (type == 1) {
                    int simId = simulator.addRobot(mappedPosition);
                    ContestRobot robot = robots.get(robotsAdded);
                    robotIdMap.put(robot.id, simId);
                    robotsAdded++;
                    System.out.println("Robot añadido en posición " + position + " (mapeada: " + mappedPosition + ")");
                } else {
                    int tenges = Integer.parseInt(parts[2]);
                    simulator.addStore(mappedPosition, tenges);
                    storesAdded++;
                    System.out.println("Tienda añadida en posición " + position + " con " + tenges + " tenges (mapeada: " + mappedPosition + ")");
                }
                
                Thread.sleep(delayBetweenMoves);
                
                System.out.println("Estado: Robots=" + robotsAdded + ", Tiendas=" + storesAdded + ", Ganancia máxima=" + solution.maxProfit);
                
                if (!solution.assignments.isEmpty()) {
                    System.out.println("Movimientos óptimos:");
                    
                    for (Assignment assignment : solution.assignments) {
                        Integer simRobotId = robotIdMap.get(assignment.robot.id);
                        
                        if (simRobotId != null) {
                            int robotPos = mapPosition((int) assignment.robot.position, routeLength);
                            int storePos = mapPosition((int) assignment.store.position, routeLength);
                            int steps = storePos - robotPos;
                            
                            simulator.moveRobot(simRobotId, steps);
                            
                            System.out.println("  Robot " + assignment.robot.id + " -> Tienda pos " + assignment.store.position + 
                                             " (distancia=" + assignment.distance + ", tenges=" + assignment.store.tenges + 
                                             ", ganancia=" + assignment.profit + ")");
                            
                            Thread.sleep(delayBetweenMoves);
                        }
                    }
                    
                    System.out.println("Ganancia del día: " + solution.maxProfit);
                } else {
                    System.out.println("No hay movimientos rentables");
                }
                
                System.out.println();
                Thread.sleep(delayBetweenDays);
            }
            
            long totalProfit = solutions.stream().mapToLong(s -> s.maxProfit).sum();
            
            System.out.println("\n=== SIMULACIÓN COMPLETADA ===");
            System.out.println("Días simulados: " + solutions.size());
            System.out.println("Robots totales: " + robots.size());
            System.out.println("Tiendas totales: " + stores.size());
            System.out.println("\nGanancias por día:");
            for (DaySolution sol : solutions) {
                System.out.println("  Día " + sol.day + ": " + sol.maxProfit);
            }
            System.out.println("\nGanancia total acumulada: " + totalProfit);
            
        } catch (Exception e) {
            System.out.println("Error durante la simulación: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * Mapea posición a ruta visual.
     * 
     * Principio: Single Responsibility - solo mapeo de coordenadas
     */
    private int mapPosition(long originalPos, int routeLength) {
        long minPos = Long.MAX_VALUE;
        long maxPos = Long.MIN_VALUE;
        
        for (ContestRobot robot : robots) {
            minPos = Math.min(minPos, robot.position);
            maxPos = Math.max(maxPos, robot.position);
        }
        
        for (ContestStore store : stores) {
            minPos = Math.min(minPos, store.position);
            maxPos = Math.max(maxPos, store.position);
        }
        
        if (maxPos - minPos < routeLength - 10) {
            return (int) (originalPos - minPos + 5);
        }
        
        long range = maxPos - minPos;
        if (range == 0) return routeLength / 2;
        
        double ratio = (double) (originalPos - minPos) / range;
        return (int) (ratio * (routeLength - 10)) + 5;
    }
    
    /**
     * Determina distancia máxima necesaria.
     */
    private long determineLongestDistance() {
        long maxPos = 0;
        
        for (ContestRobot robot : robots) {
            maxPos = Math.max(maxPos, Math.abs(robot.position));
        }
        
        for (ContestStore store : stores) {
            maxPos = Math.max(maxPos, Math.abs(store.position));
        }
        
        return maxPos;
    }
    
    /**
     * Método main de ejemplo.
     */
    public static void main(String[] args) {
        SilkRoadContest contest = new SilkRoadContest();
        
        System.out.println("=== SILK ROAD CONTEST ===");
        System.out.println("Elija una opción:");
        System.out.println("1. Solve (solo resultados)");
        System.out.println("2. Simulate (con visualización)");
        System.out.print("Opción: ");
        
        Scanner sc = new Scanner(System.in);
        int option = sc.nextInt();
        
        if (option == 1) {
            contest.solve();
        } else if (option == 2) {
            contest.simulate();
        } else {
            System.out.println("Opción inválida");
        }
    }
}