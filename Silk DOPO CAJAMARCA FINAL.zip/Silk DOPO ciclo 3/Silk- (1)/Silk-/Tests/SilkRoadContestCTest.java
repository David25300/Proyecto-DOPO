package Tests;

import Solver.SilkRoadContest;
import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;
import java.io.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class SilkRoadContestCTest {
    
    private SilkRoadContest contest;
    private ByteArrayOutputStream outputStream;
    private PrintStream originalOut;
    private InputStream originalIn;
    
    @BeforeEach
    public void setUp() {
        contest = new SilkRoadContest();
        outputStream = new ByteArrayOutputStream();
        originalOut = System.out;
        originalIn = System.in;
        System.setOut(new PrintStream(outputStream));
    }
    
    @AfterEach
    public void tearDown() {
        System.setOut(originalOut);
        System.setIn(originalIn);
    }
    
    @Test
    @Order(1)
    public void testContestCreation() {
        assertNotNull(contest);
    }
    
    @Test
    @Order(2)
    public void testSolveWithSimpleInput() {
        String input = "2\n1 5\n2 10 50\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        
        contest = new SilkRoadContest();
        contest.solve();
        
        String output = outputStream.toString();
        assertTrue(output.contains("RESULTADOS"));
    }
    
    @Test
    @Order(3)
    public void testSolveWithZeroDays() {
        String input = "0\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        
        contest = new SilkRoadContest();
        contest.solve();
        
        String output = outputStream.toString();
        assertTrue(output.contains("Error"));
    }
    
    @Test
    @Order(4)
    public void testSolveWithNegativeDays() {
        String input = "-1\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        
        contest = new SilkRoadContest();
        contest.solve();
        
        String output = outputStream.toString();
        assertTrue(output.contains("Error"));
    }
    
    @Test
    @Order(5)
    public void testSolveWithInvalidFormat() {
        String input = "2\nabc xyz\n2 10 50\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        
        contest = new SilkRoadContest();
        contest.solve();
        
        String output = outputStream.toString();
        assertTrue(output.contains("Error") || output.contains("invÃ¡lido"));
    }
    
    @Test
    @Order(6)
    public void testSolveWithMultipleRobots() {
        String input = "3\n1 5\n1 15\n2 10 100\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        
        contest = new SilkRoadContest();
        contest.solve();
        
        String output = outputStream.toString();
        assertTrue(output.contains("RESULTADOS"));
        assertTrue(output.contains("Día 1"));
    }
    
    @Test
    @Order(7)
    public void testSolveWithMultipleStores() {
        String input = "3\n1 5\n2 10 100\n2 15 80\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        
        contest = new SilkRoadContest();
        contest.solve();
        
        String output = outputStream.toString();
        assertTrue(output.contains("RESULTADOS"));
    }
    
    @Test
    @Order(8)
    public void testSolveWithNoProfitScenario() {
        String input = "2\n1 5\n2 20 5\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        
        contest = new SilkRoadContest();
        contest.solve();
        
        String output = outputStream.toString();
        assertTrue(output.contains("RESULTADOS"));
    }
    
    @Test
    @Order(9)
    public void testSolveWithOptimalAssignments() {
        String input = "4\n1 0\n1 10\n2 5 50\n2 15 60\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        
        contest = new SilkRoadContest();
        contest.solve();
        
        String output = outputStream.toString();
        assertTrue(output.contains("RESULTADOS"));
        assertTrue(output.contains("Ganancia total"));
    }
    
    @Test
    @Order(10)
    public void testSolveWithLargeDayCount() {
        StringBuilder input = new StringBuilder("10\n");
        for (int i = 0; i < 5; i++) {
            input.append("1 ").append(i * 10).append("\n");
        }
        for (int i = 0; i < 5; i++) {
            input.append("2 ").append(i * 10 + 5).append(" ").append((i + 1) * 20).append("\n");
        }
        
        System.setIn(new ByteArrayInputStream(input.toString().getBytes()));
        
        contest = new SilkRoadContest();
        contest.solve();
        
        String output = outputStream.toString();
        assertTrue(output.contains("RESULTADOS"));
    }
    @Test
    @Order(11)
    public void testSimulateWithSlowSpeed() {
        String input = "2\n1 5\n2 10 50\n1\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        
        contest = new SilkRoadContest();
        contest.simulate();
        
        String output = outputStream.toString();
        assertTrue(output.contains("SIMULACIÓN") || output.contains("LENTO"));
    }
    
    @Test
    @Order(12)
    public void testSimulateWithFastSpeed() {
        String input = "2\n1 5\n2 10 50\n2\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        
        contest = new SilkRoadContest();
        contest.simulate();
        
        String output = outputStream.toString();
        assertTrue(output.contains("SIMULACIÓN") || output.contains("RÁPIDO"));
    }
    
    @Test
    @Order(13)
    public void testSimulateWithInvalidSpeed() {
        String input = "2\n1 5\n2 10 50\n5\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        
        contest = new SilkRoadContest();
        contest.simulate();
        
        String output = outputStream.toString();
        assertTrue(output.contains("SIMULACIÓN"));
    }
    
    @Test
    @Order(14)
    public void testSimulateShowsMovements() {
        String input = "2\n1 5\n2 10 50\n2\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        
        contest = new SilkRoadContest();
        contest.simulate();
        
        String output = outputStream.toString();
        assertTrue(output.contains("Robot") || output.contains("Tienda"));
    }
    
    @Test
    @Order(15)
    public void testSimulateCompletesAllDays() {
        String input = "3\n1 5\n2 10 50\n1 15\n2\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        
        contest = new SilkRoadContest();
        contest.simulate();
        
        String output = outputStream.toString();
        assertTrue(output.contains("COMPLETADA"));
    }
    
    @Test
    @Order(16)
    public void testSimulateCalculatesProfit() {
        String input = "2\n1 5\n2 10 50\n2\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        
        contest = new SilkRoadContest();
        contest.simulate();
        
        String output = outputStream.toString();
        assertTrue(output.contains("Ganancia") || output.contains("ganancia"));
    }
    
    @Test
    @Order(17)
    public void testSimulateWithNoProfitableMoves() {
        String input = "2\n1 5\n2 30 10\n2\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        
        contest = new SilkRoadContest();
        contest.simulate();
        
        String output = outputStream.toString();
        assertTrue(output.contains("SIMULACIÓN"));
    }
}