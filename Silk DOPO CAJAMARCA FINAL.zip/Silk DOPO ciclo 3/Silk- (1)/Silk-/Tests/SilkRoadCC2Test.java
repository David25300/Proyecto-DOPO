package Tests;

import Simulator.*;
import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;
import java.util.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class SilkRoadCC2Test {
    
    private SilkRoad silkRoad;
    
    @BeforeEach
    public void setUp() {
        silkRoad = new SilkRoad();
    }
    
    @AfterEach
    public void tearDown() {
        if (silkRoad != null) {
            silkRoad.finish();
        }
    }
    
    @Test
    @Order(1)
    public void testCreateBasicRoute() {
        silkRoad.create(10);
        
        assertNotNull(silkRoad);
        assertFalse(silkRoad.isICPCMode());
        assertEquals(0.0, silkRoad.getProfit(), 0.001);
    }
    
    @Test
    @Order(2)
    public void testCreateRouteWithNegativeLength() {
        assertThrows(IllegalArgumentException.class, () -> {
            silkRoad.create(-5);
        });
    }
    
    @Test
    @Order(3)
    public void testCreateRouteWithZeroLength() {
        assertThrows(IllegalArgumentException.class, () -> {
            silkRoad.create(0);
        });
    }
    
    @Test
    @Order(4)
    public void testAddRobotSuccess() {
        silkRoad.create(20);
        
        int robotId = silkRoad.addRobot(5);
        
        assertTrue(robotId > 0);
        assertEquals(1, silkRoad.getRobots().size());
    }
    
    @Test
    @Order(5)
    public void testAddRobotBeforeCreatingRoute() {
        int robotId = silkRoad.addRobot(5);
        
        assertEquals(-1, robotId);
    }
    
    @Test
    @Order(6)
    public void testAddRobotOutOfBounds() {
        silkRoad.create(10);
        
        int robotId = silkRoad.addRobot(50);
        
        assertEquals(-1, robotId);
    }
    
    @Test
    @Order(7)
    public void testAddRobotAtSamePosition() {
        silkRoad.create(20);
        
        int robot1 = silkRoad.addRobot(5);
        int robot2 = silkRoad.addRobot(5);
        
        assertTrue(robot1 > 0);
        assertEquals(-1, robot2);
        assertEquals(1, silkRoad.getRobots().size());
    }
    
    @Test
    @Order(8)
    public void testAddStoreSuccess() {
        silkRoad.create(20);
        
        boolean result = silkRoad.addStore(8, 100);
        
        assertTrue(result);
        assertEquals(1, silkRoad.getStores().size());
    }
    
    @Test
    @Order(9)
    public void testAddStoreWithZeroTenges() {
        silkRoad.create(20);
        
        boolean result = silkRoad.addStore(8, 0);
        
        assertTrue(result);
        assertEquals(0, silkRoad.getStores().get(0).getTenges());
    }
    
    @Test
    @Order(10)
    public void testAddStoreAtRobotPosition() {
        silkRoad.create(20);
        silkRoad.addRobot(5);
        
        boolean result = silkRoad.addStore(5, 50);
        
        assertFalse(result);
        assertEquals(0, silkRoad.getStores().size());
    }
}

