package Tests;

import Simulator.SilkRoad;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * Pruebas unitarias requeridas por el profesor - Ciclo 2
 * Contiene solo las 4 pruebas especificadas por el profesor
 * 
 * @author Profesor (Ciclo 2)
 * @version 1.0
 */
public class SilkRoadC2Test {
    
    private SilkRoad silkRoad;
    
    @BeforeEach
    public void setUp() {
        silkRoad = new SilkRoad(20);
    }
    
    /**
     * Verifica que showRobotProfits muestre correctamente las ganancias de un robot e 
     * identifica bugs.
     * 
     * Requisito 13: Consultar ganancias por movimiento de cada robot
     */
    @Test
    public void ShowRobotProfitsLRShouldDisplayCorrectProfits() {
        // Arrange
        int robotId = silkRoad.placeRobot(0);
        silkRoad.placeStore(1, 50);
        silkRoad.placeStore(3, 100);
        
        // Act
        silkRoad.moveRobot(robotId, 1);
        silkRoad.moveRobot(robotId, 2);
        
        // Assert
        // Primera ganancia: 50 - 1 = 49
        // Segunda ganancia: 100 - 2 = 98
        // Total: 147
        assertEquals(147, silkRoad.profit());
    }
    
    /**
     * profit suma correctamente los tenges de todos los robots después de recolectar
     * 
     * Requisito 6: Consultar ganancias
     */
    @Test
    public void profitLRShouldCalculateTotalTengesFromAllRobots() {
        // Arrange
        int robot1 = silkRoad.placeRobot(1);
        int robot2 = silkRoad.placeRobot(5);
        silkRoad.placeStore(3, 100);
        silkRoad.placeStore(7, 200);
        
        // Act
        silkRoad.moveRobot(robot1, 2);
        silkRoad.moveRobot(robot2, 2);
        
        // Assert
        int totalProfit = (int) silkRoad.profit();
        assertTrue(totalProfit >= 0);
    }
    
    /**
     * No debe mover el robot cuando no hay movimiento beneficioso disponible.
     * Una tienda vacía o movimiento con ganancia negativa no debe ejecutarse.
     * 
     * Requisito: Manejo de errores en movimientos
     */
    @Test
    public void shouldNotMoveRobotWhenNoGoodMoveAvailable() {
        // Arrange
        silkRoad.placeStore(3, 0);  // Tienda vacía
        int robotId = silkRoad.placeRobot(0);
        
        // Act
        boolean result = silkRoad.moveRobot(robotId);
        
        // Assert
        assertFalse(silkRoad.ok());
        assertEquals("No hay movimiento beneficioso disponible para el robot",
                     silkRoad.getLastError());
    }
    
    /**
     * Debe registrar y retornar las ganancias de cada movimiento por robot.
     * 
     * Requisito 13: Consultar ganancias por movimiento de cada robot
     */
    @Test
    public void shouldTrackRobotProfitsPerMove() {
        // Arrange
        SilkRoad road = new SilkRoad(50);
        road.placeStore(10, 30);   // Tienda con 30 monedas
        road.placeStore(20, 40);   // Tienda con 40 monedas
        int robotId = road.placeRobot(5);  // Robot empieza en 5
        
        // Act
        // Mover robot dos veces para que acumule ganancias
        road.moveRobot(robotId, 5);   // Mover 5 pasos (a pos 10) - recoger 30, costo 5, ganancia 25
        road.moveRobot(robotId, 10);  // Mover 10 pasos (a pos 20) - recoger 40, costo 10, ganancia 30
        
        int[][] profits = road.profitPerMove();
        
        // Assert
        // Validamos que haya un registro para el robot
        assertEquals(1, profits.length);
        
        // La primera columna es la posición del robot (ID del robot)
        assertEquals(robotId, profits[0][0]);
        
        // Las siguientes son las ganancias por movimiento
        assertTrue(profits[0][1] > 0);  // Primera ganancia (30 - 5 = 25)
        assertTrue(profits[0][2] > 0);  // Segunda ganancia (40 - 10 = 30)
        
        System.out.println("Ganancias registradas por el robot: " 
                         + profits[0][1] + ", " + profits[0][2]);
    }
}
