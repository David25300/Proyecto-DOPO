package Simulator;


/**
 * Representa una tienda en la ruta de seda - CICLO 2.
 * Cada tienda contiene tenges (moneda) que pueden ser recogidos por los robots.
 * Incluye soporte para posiciones originales del problema ICPC.
 * 
 * Principio de Responsabilidad Única: Solo maneja el estado y 
 * comportamiento de una tienda individual.
 * 
 * @author Santiago aCjamarca
 * @version 3.0 - Ciclo 2
 */
public class Store {
    
    private int position;           
    private int originalPosition;   
    private int tenges;
    private int initialTenges;
    private Circle visual;
    private String color;
    private static int colorIndex = 0;
    private static final String[] COLORS = {"blue", "green", "magenta", "red", "cyan", "orange"};
    
    // para Ciclo 2
    private int timesEmptied;       // Contador de veces que ha sido vaciada
    private boolean isEmpty;        // Estado actual de la tienda (vacia o no vacia)
    private boolean isRobable;      // Indica si la tienda puede ser robada
    
    /**
     * Constructor de Store.
     * 
     * @param position La posición en la ruta donde se ubica la tienda
     * @param tenges La cantidad inicial de tenges en la tienda
     */
    public Store(int position, int tenges) {
        this(position, tenges, true); // Por defecto, las tiendas son robables
    }
    
    /**
     * Constructor de Store con opción de protección.
     * 
     * @param position La posición en la ruta donde se ubica la tienda
     * @param tenges La cantidad inicial de tenges en la tienda
     * @param isRobable true si la tienda puede ser robada, false si está protegida
     */
    public Store(int position, int tenges, boolean isRobable) {
        this.position = position;
        this.originalPosition = position; 
        this.tenges = tenges;
        this.initialTenges = tenges;
        this.timesEmptied = 0;
        this.isEmpty = false;
        this.isRobable = isRobable;
        
        // Asignar un color único a cada tienda
        // Tiendas no robables usan color especial (amarillo/dorado)
        if (!isRobable) {
            this.color = "yellow";
        } else {
            this.color = COLORS[colorIndex % COLORS.length];
            colorIndex++;
        }
        
        // Crear la representación visual
        visual = new Circle();
        visual.changeSize(20);
        visual.changeColor(color);
    }
    
    /**
     * Establece la posición original del problema ICPC.
     * Requisito 10: Soporte ICPC
     * 
     * @param originalPosition La posición original del ICPC
     */
    public void setOriginalPosition(int originalPosition) {
        this.originalPosition = originalPosition;
    }
    
    /**
     * Obtiene la posición original del problema ICPC.
     * Requisito 10: Soporte ICPC
     * 
     * @return La posición original del ICPC
     */
    public int getOriginalPosition() {
        return originalPosition;
    }
    
    /**
     * Posiciona la tienda en las coordenadas especificadas.
     * 
     * @param x La coordenada x
     * @param y La coordenada y
     */
    public void setPosition(int x, int y) {
        if (visual != null) {
            visual.makeInvisible();
        }
        
        visual = new Circle();
        visual.changeSize(20);
        updateVisualAppearance(); 
  
        int deltaX = x - 20;
        int deltaY = y - 15;
        
        // Mover a la posición deseada
        if (deltaX != 0) {
            visual.moveHorizontal(deltaX);
        }
        if (deltaY != 0) {
            visual.moveVertical(deltaY);
        }
    }
    
    /**
     * Actualiza la apariencia visual de la tienda según su estado.
     * Requisito de usabilidad: tiendas desocupadas deben lucir diferentes
     * Tiendas no robables mantienen su color distintivo
     */
    private void updateVisualAppearance() {
        if (isEmpty && isRobable) {
            // Tienda vacía y robable - usar color diferente
            visual.changeColor("white");
        } else {
            // Tienda con tenges o protegida - usar color original
            visual.changeColor(color);
        }
    }
    
    /**
     * Hace visible la tienda.
     */
    public void makeVisible() {
        updateVisualAppearance(); // apariencia correcta
        visual.makeVisible();
    }
    
    /**
     * Hace invisible la tienda.
     */
    public void makeInvisible() {
        visual.makeInvisible();
    }
    
    /**
     * Reabastece la tienda con su cantidad inicial de tenges.
     * Usado para el requisito de resupply stores.
     */
    public void resupply() {
        this.tenges = this.initialTenges;
        this.isEmpty = false;
        updateVisualAppearance();
    }
    
    /**
     * Recoge todos los tenges de la tienda.
     * La tienda queda vacía después de esta operación.
     * Ciclo 2: Incluye contador de veces vaciada
     * NUEVO: Las tiendas no robables no pueden ser robadas
     * 
     * @return La cantidad de tenges recogidos (0 si la tienda no es robable)
     */
    public int collectAll() {
        // Si la tienda no es robable, no se puede robar
        if (!isRobable) {
            return 0;
        }
        
        int collected = tenges;
        
        if (collected > 0) {
            tenges = 0;
            isEmpty = true;
            timesEmptied++;
            updateVisualAppearance();
        }
        
        return collected;
    }
    
    /**
     * Obtiene el número de veces que la tienda ha sido desocupada.
     * Requisito 12: Consultar número de veces desocupada
     * 
     * @return El número de veces que ha sido vaciada
     */
    public int getTimesEmptied() {
        return timesEmptied;
    }
    
    /**
     * Reinicia el contador de veces vaciada.
     * Requisito 12: Para reset de estadísticas
     */
    public void resetTimesEmptied() {
        this.timesEmptied = 0;
    }
    
    /**
     * Obtiene la cantidad actual de tenges en la tienda.
     * 
     * @return La cantidad actual de tenges
     */
    public int getTenges() {
        return tenges;
    }
    
    /**
     * Obtiene la cantidad inicial de tenges de la tienda.
     * 
     * @return La cantidad inicial de tenges
     */
    public int getInitialTenges() {
        return initialTenges;
    }
    
    /**
     * Obtiene la posición de la tienda en la ruta mapeada.
     * 
     * @return La posición de la tienda
     */
    public int getPosition() {
        return position;
    }
    
    /**
     * Obtiene el color de la tienda.
     * 
     * @return El color de la tienda
     */
    public String getColor() {
        return color;
    }
    
    /**
     * Verifica si la tienda está vacía.
     * 
     * @return true si no tiene tenges, false en caso contrario
     */
    public boolean isEmpty() {
        return isEmpty;
    }
    
    /**
     * Verifica si la tienda puede ser robada.
     * 
     * @return true si la tienda es robable, false si está protegida
     */
    public boolean isRobable() {
        return isRobable;
    }
    
    /**
     * Obtiene información completa de la tienda.
     * NUEVO - Ciclo 2: Incluye estadísticas adicionales
     * 
     * @return String con información detallada
     */
    public String getDetailedInfo() {
        return String.format(
            "Tienda - Pos: %d (orig: %d), Tenges: %d/%d, Vaciada: %d veces, Estado: %s, Protegida: %s",
            position, originalPosition, tenges, initialTenges, timesEmptied,
            isEmpty ? "Vacía" : "Con tenges",
            isRobable ? "No" : "Sí"
        );
    }
}
