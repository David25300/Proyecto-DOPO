package Simulator;


import java.util.*;

/**
 * Representa un robot que puede moverse por la ruta de seda - CICLO 2.
 * Cada robot puede recoger tenges de las tiendas, con un costo de 1 tenge por segmento movido.
 * Incluye soporte para posiciones originales ICPC y registro detallado de movimientos.
 * 
 * Principio de Responsabilidad Única: Solo maneja el estado y 
 * comportamiento de un robot individual.
 * Principio Abierto/Cerrado: Extensible para nuevos tipos de registro
 * 
 * @author Santiago Cajamarca
 * @version 3.1 - Ciclo 2 (Mejorado para requisito 13)
 */
public class Robot {
    
    private static int nextId = 1;
    private int id;
    private int currentPosition;
    private int initialPosition;
    private int originalInitialPosition;  
    private int tengesCollected;
    private int costIncurred;
    private Triangle visual;
    private String color;
    private boolean isCurrentlyVisible;
    private static int colorIndex = 0;
    private static final String[] COLORS = {"green", "magenta", "blue", "red", "cyan", "orange"};
    
    // Para Ciclo 2 - Registro de movimientos (Requisito 13)
    private List<MovementRecord> movementHistory;
    private boolean shouldBlink; // Para el robot con mayor ganancia
    private Thread blinkThread; 
    
    /**
     * Constructor de Robot.
     * 
     * @param initialPosition La posición inicial del robot en la ruta
     * @param maxCapacity La capacidad máxima (no usado en este problema, pero mantenido por extensibilidad)
     */
    public Robot(int initialPosition, int maxCapacity) {
        this.id = nextId++;
        this.initialPosition = initialPosition;
        this.originalInitialPosition = initialPosition; 
        this.currentPosition = initialPosition;
        this.tengesCollected = 0;
        this.costIncurred = 0;
        this.isCurrentlyVisible = false;
        this.shouldBlink = false;
        this.movementHistory = new ArrayList<>();
        
        // Asigna un color único a cada robot
        this.color = COLORS[colorIndex % COLORS.length];
        colorIndex++;
        
        visual = new Triangle();
        visual.changeSize(20, 20);
        visual.changeColor(color);
    }
    
    /**
     * Establece la posición inicial original del problema ICPC.
     * Requisito 10: Soporte ICPC
     * 
     * @param originalPosition La posición original del ICPC
     */
    public void setOriginalInitialPosition(int originalPosition) {
        this.originalInitialPosition = originalPosition;
    }
    
    /**
     * Obtiene la posición inicial original del problema ICPC.
     * Requisito 10: Soporte ICPC
     * 
     * @return La posición original del ICPC
     */
    public int getOriginalInitialPosition() {
        return originalInitialPosition;
    }
    
    /**
     * Registro de un movimiento individual.
     * MEJORADO - Requisito 13: Registrar ganancias por movimiento con más detalle
     * Principio de Inmutabilidad: Clase inmutable para registros
     */
    public static class MovementRecord {
        private final int fromPosition;
        private final int toPosition;
        private final int steps;
        private final int cost;
        private final int tengesCollected;
        private final int netProfit;
        private final long timestamp;
        private final int movementNumber;
        
        public MovementRecord(int from, int to, int steps, int cost, int collected, int profit, int movementNum) {
            this.fromPosition = from;
            this.toPosition = to;
            this.steps = steps;
            this.cost = cost;
            this.tengesCollected = collected;
            this.netProfit = profit;
            this.timestamp = System.currentTimeMillis();
            this.movementNumber = movementNum;
        }
        
        // Constructor sobrecargado para compatibilidad
        public MovementRecord(int from, int to, int steps, int cost, int collected, int profit) {
            this(from, to, steps, cost, collected, profit, 0);
        }
        
        // Getters (solo lectura - inmutabilidad)
        public int getFromPosition() { return fromPosition; }
        public int getToPosition() { return toPosition; }
        public int getSteps() { return steps; }
        public int getCost() { return cost; }
        public int getTengesCollected() { return tengesCollected; }
        public int getNetProfit() { return netProfit; }
        public long getTimestamp() { return timestamp; }
        public int getMovementNumber() { return movementNumber; }
        
        /**
         * Verifica si el movimiento fue rentable.
         * 
         * @return true si la ganancia neta es positiva
         */
        public boolean isProfitable() {
            return netProfit > 0;
        }
        
        @Override
        public String toString() {
            return String.format("Mov #%d: %d→%d (%d pasos), Costo:%d, Recogió:%d, Ganancia:%d %s",
                movementNumber, fromPosition, toPosition, steps, cost, tengesCollected, netProfit,
                isProfitable() ? "✓" : "✗");
        }
    }
    
    /**
     * Posiciona el robot visualmente en las coordenadas especificadas.
     * Mantiene el estado de visibilidad.
     * 
     * @param x La coordenada x
     * @param y La coordenada y
     */
    public void setVisualPosition(int x, int y) {
        stopBlinking();
        
        if (visual != null) {
            visual.makeInvisible();
        }
 
        visual = new Triangle();
        visual.changeSize(20, 20);
        visual.changeColor(color);

        int deltaX = x - 140;
        int deltaY = y - 15;

        if (deltaX != 0) {
            visual.moveHorizontal(deltaX);
        }
        if (deltaY != 0) {
            visual.moveVertical(deltaY);
        }

        if (isCurrentlyVisible) {
            visual.makeVisible();
 
            if (shouldBlink) {
                startBlinking();
            }
        }
    }
    
    /**
     * Mueve el robot a una nueva posición en la ruta.
     * MEJORADO - Requisito 13: Registra el movimiento con información detallada
     * Principio de Cohesión: Mantiene toda la lógica de movimiento junta
     * 
     * @param newPosition La nueva posición
     * @param steps Número de pasos dados
     * @param cost Costo del movimiento
     * @param tengesCollected Tenges recogidos en este movimiento
     */
    public void moveTo(int newPosition, int steps, int cost, int tengesCollected) {
        int oldPosition = this.currentPosition;
        
        // Calcular ganancia neta
        int netProfit = tengesCollected - cost;
        
        // Crear registro con número de movimiento
        MovementRecord movement = new MovementRecord(
            oldPosition, 
            newPosition, 
            steps, 
            cost, 
            tengesCollected, 
            netProfit,
            movementHistory.size() + 1  // Número de movimiento
        );
        
        // Agregar al historial
        movementHistory.add(movement);
        
        // Actualizar posición
        this.currentPosition = newPosition;
    }
    
    /**
     * Sobrecarga para compatibilidad con código existente.
     * 
     * @param newPosition La nueva posición
     */
    public void moveTo(int newPosition) {
        moveTo(newPosition, 0, 0, 0);
    }
    
    /**
     * Retorna el robot a su posición inicial.
     * Usado para el requisito de return robots.
     * No registra este movimiento para evitar confusiones en estadísticas
     */
    public void returnToInitialPosition() {
        this.currentPosition = this.initialPosition;
    }
    
    /**
     * Añade costo al movimiento del robot.
     * Cada segmento movido cuesta 1 tenge.
     * 
     * @param cost El costo a añadir
     */
    public void addCost(int cost) {
        this.costIncurred += cost;
    }
    
    /**
     * Establece el costo incurrido.
     * 
     * @param cost El nuevo costo
     */
    public void setCostIncurred(int cost) {
        this.costIncurred = cost;
    }
    
    /**
     * El robot recoge tenges.
     * 
     * @param amount La cantidad de tenges recogidos
     */
    public void collectTenges(int amount) {
        this.tengesCollected += amount;
    }
    
    /**
     * Reinicia los tenges recogidos.
     */
    public void resetTengesCollected() {
        this.tengesCollected = 0;
    }
    
    /**
     * Limpia el historial de movimientos.
     * Requisito 13: Para reset de estadísticas
     * Principio de Encapsulamiento: Mantiene control sobre el estado interno
     */
    public void clearMovementHistory() {
        this.movementHistory.clear();
    }
    
    /**
     * Obtiene el historial completo de movimientos.
     * Requisito 13: Consultar ganancias por movimiento
     * Principio de Inmutabilidad: Retorna lista no modificable
     * 
     * @return Lista inmutable del historial de movimientos
     */
    public List<MovementRecord> getMovementHistory() {
        return Collections.unmodifiableList(movementHistory);
    }
    
    /**
     * Obtiene las ganancias de cada movimiento como lista.
     * Requisito 13: Consultar ganancias por movimiento
     * Principio de Responsabilidad Única: Método específico para ganancias
     * 
     * @return Lista de ganancias netas por movimiento
     */
    public List<Integer> getMovementProfits() {
        List<Integer> profits = new ArrayList<>();
        for (MovementRecord record : movementHistory) {
            profits.add(record.getNetProfit());
        }
        return profits;
    }
    
    /**
     * Obtiene el mejor movimiento realizado.
     * Requisito 13: Análisis de movimientos
     * 
     * @return El movimiento más rentable o null si no hay movimientos
     */
    public MovementRecord getBestMovement() {
        return movementHistory.stream()
            .max(Comparator.comparingInt(MovementRecord::getNetProfit))
            .orElse(null);
    }
    
    /**
     * Obtiene el peor movimiento realizado.
     * Requisito 13: Análisis de movimientos
     * 
     * @return El movimiento menos rentable o null si no hay movimientos
     */
    public MovementRecord getWorstMovement() {
        return movementHistory.stream()
            .min(Comparator.comparingInt(MovementRecord::getNetProfit))
            .orElse(null);
    }
    
    /**
     * Calcula estadísticas de movimientos.
     * Requisito 13: Análisis detallado
     * Principio de Cohesión: Agrupa cálculos relacionados
     * 
     * @return Mapa con estadísticas clave
     */
    public Map<String, Double> getMovementStatistics() {
        Map<String, Double> stats = new HashMap<>();
        
        if (movementHistory.isEmpty()) {
            stats.put("totalMovements", 0.0);
            stats.put("avgProfit", 0.0);
            stats.put("maxProfit", 0.0);
            stats.put("minProfit", 0.0);
            stats.put("profitableMovements", 0.0);
            stats.put("profitabilityRate", 0.0);
            return stats;
        }
        
        List<Integer> profits = getMovementProfits();
        
        stats.put("totalMovements", (double) movementHistory.size());
        stats.put("avgProfit", profits.stream().mapToInt(Integer::intValue).average().orElse(0));
        stats.put("maxProfit", (double) Collections.max(profits));
        stats.put("minProfit", (double) Collections.min(profits));
        
        long profitableCount = movementHistory.stream().filter(MovementRecord::isProfitable).count();
        stats.put("profitableMovements", (double) profitableCount);
        stats.put("profitabilityRate", (double) profitableCount / movementHistory.size() * 100);
        
        return stats;
    }
    
    /**
     * Obtiene un resumen detallado de todos los movimientos.
     * Requisito 13: Información detallada
     * Principio de Presentación: Formatea información para fácil lectura
     * 
     * @return String con resumen de movimientos
     */
    public String getMovementSummary() {
        if (movementHistory.isEmpty()) {
            return "Robot " + id + ": Sin movimientos registrados";
        }
        
        StringBuilder summary = new StringBuilder();
        summary.append("=== Resumen de Movimientos - Robot ").append(id).append(" ===\n");
        
        Map<String, Double> stats = getMovementStatistics();
        
        summary.append(String.format("Total movimientos: %.0f\n", stats.get("totalMovements")));
        summary.append(String.format("Ganancia total: %d\n", getNetProfit()));
        summary.append(String.format("Costo total: %d\n", costIncurred));
        summary.append(String.format("Tenges recogidos: %d\n", tengesCollected));
        summary.append(String.format("Ganancia promedio: %.2f\n", stats.get("avgProfit")));
        summary.append(String.format("Movimientos rentables: %.0f/%.0f (%.1f%%)\n", 
            stats.get("profitableMovements"), stats.get("totalMovements"), stats.get("profitabilityRate")));
        
        MovementRecord bestMove = getBestMovement();
        MovementRecord worstMove = getWorstMovement();
        
        if (bestMove != null) {
            summary.append("Mejor movimiento: ").append(bestMove.toString()).append("\n");
        }
        if (worstMove != null && worstMove != bestMove) {
            summary.append("Peor movimiento: ").append(worstMove.toString()).append("\n");
        }
        
        summary.append("\nDetalle por movimiento:\n");
        for (MovementRecord record : movementHistory) {
            summary.append("  ").append(record.toString()).append("\n");
        }
        
        return summary.toString();
    }
    
    /**
     * Activa el parpadeo del robot.
     * Requisito de usabilidad: robot con mayor ganancia debe parpadear
     * Principio de Responsabilidad Única: Manejo visual separado
     */
    public void startBlinking() {
        if (shouldBlink || !isCurrentlyVisible) {
            return;
        }
        
        shouldBlink = true;
        
        blinkThread = new Thread(() -> {
            String originalColor = color;
            boolean isOriginalColor = true;
            
            while (shouldBlink && isCurrentlyVisible) {
                try {
                    if (isOriginalColor) {
                        visual.changeColor("white");
                    } else {
                        visual.changeColor(originalColor);
                    }
                    isOriginalColor = !isOriginalColor;
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    break;
                }
            }
            
            if (isCurrentlyVisible) {
                visual.changeColor(originalColor);
            }
        });
        
        blinkThread.start();
    }
    
    /**
     * Detiene el parpadeo del robot.
     * Requisito de usabilidad: control del parpadeo
     */
    public void stopBlinking() {
        shouldBlink = false;
        
        if (blinkThread != null && blinkThread.isAlive()) {
            blinkThread.interrupt();
            try {
                blinkThread.join(100); 
            } catch (InterruptedException e) {
                // Ignorar
            }
        }
        
        if (isCurrentlyVisible && visual != null) {
            visual.changeColor(color);
        }
    }
    
    /**
     * Verifica si el robot está parpadeando.
     * 
     * @return true si está parpadeando, false en caso contrario
     */
    public boolean isBlinking() {
        return shouldBlink;
    }
    
    /**
     * Hace visible el robot.
     */
    public void makeVisible() {
        isCurrentlyVisible = true;
        visual.makeVisible();
        
        if (shouldBlink) {
            startBlinking();
        }
    }
    
    /**
     * Hace invisible el robot.
     */
    public void makeInvisible() {
        stopBlinking();
        isCurrentlyVisible = false;
        visual.makeInvisible();
    }
    
    /**
     * Verifica si el robot está visible.
     * 
     * @return true si está visible, false en caso contrario
     */
    public boolean isVisible() {
        return isCurrentlyVisible;
    }
    
    // Getters básicos
    
    public int getId() {
        return id;
    }
    
    public int getCurrentPosition() {
        return currentPosition;
    }
    
    public int getInitialPosition() {
        return initialPosition;
    }
    
    public int getTengesCollected() {
        return tengesCollected;
    }
    
    public int getCostIncurred() {
        return costIncurred;
    }
    
    /**
     * Calcula la ganancia neta del robot.
     * 
     * @return La ganancia (tenges recogidos - costo incurrido)
     */
    public int getNetProfit() {
        return tengesCollected - costIncurred;
    }
    
    public String getColor() {
        return color;
    }
    
    /**
     * Obtiene información del robot como string.
     * Ciclo 2: Incluye información adicional de estadísticas
     * 
     * @return String con la información del robot
     */
    public String getInfo() {
        String blinkStatus = shouldBlink ? " (PARPADEANDO)" : "";
        Map<String, Double> stats = getMovementStatistics();
        
        return String.format("Robot %d: Pos=%d (orig=%d), Tenges=%d, Costo=%d, Ganancia=%d, Movimientos=%.0f%s", 
                           id, currentPosition, originalInitialPosition, tengesCollected, costIncurred, 
                           getNetProfit(), stats.get("totalMovements"), blinkStatus);
    }
}
