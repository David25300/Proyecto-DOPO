package Simulator;


import java.util.*;

/**
 * Representa la ruta de seda como una estructura de espiral cuadrada.
 * Gestiona la creación y visualización de los segmentos de la ruta.
 * 
 * Principio de Responsabilidad Única: Esta clase solo se encarga de la
 * estructura y visualización de la ruta.
 * @author Santiago Cajamraca
 * @version 1.0
 */
public class SilkPath {
    
    private List<PathSegment> segments;
    private int length;
    private boolean isVisible;
    private static final int SEGMENT_SIZE = 30;
    private static final int INITIAL_X = 50;
    private static final int INITIAL_Y = 50;
    private static final int SPACING = 5;
    
    /**
     * Constructor de SilkPath.
     * Crea una ruta con el número de segmentos especificado en forma de espiral.
     * 
     * @param length El número de segmentos de la ruta
     */
    public SilkPath(int length) {
        this.length = length;
        this.segments = new ArrayList<>();
        this.isVisible = false;
        createSpiralPath();
    }
    
    /**
     * Crea la ruta en forma de espiral cuadrada.
     * La espiral se expande hacia afuera desde el centro.
     */
    private void createSpiralPath() {
        int x = INITIAL_X;
        int y = INITIAL_Y;
        int stepSize = SEGMENT_SIZE + SPACING;
        
        // Direcciones: 0=derecha, 1=abajo, 2=izquierda, 3=arriba
        int direction = 0;
        int stepsInDirection = 1;
        int stepsCounter = 0;
        int directionChangeCounter = 0;
        
        for (int i = 0; i < length; i++) {
            // Crear y posicionar el segmento
            PathSegment segment = new PathSegment(i, x, y, SEGMENT_SIZE);
            segments.add(segment);
            
            // Calcular la siguiente posición siguiendo el patrón de espiral cuadrada
            stepsCounter++;
            
            // Mover en la dirección correcta
            switch (direction) {
                case 0: 
                    x += stepSize;
                    break;
                case 1: 
                    y += stepSize;
                    break;
                case 2: 
                    x -= stepSize;
                    break;
                case 3: 
                    y -= stepSize;
                    break;
            }
            
            // Verificar si necesita cambiar de dirección
            if (stepsCounter == stepsInDirection) {
                stepsCounter = 0;
                direction = (direction + 1) % 4;
                directionChangeCounter++;
                
                // Cada dos cambios de dirección, incrementamos los pasos en esa dirección
                if (directionChangeCounter % 2 == 0) {
                    stepsInDirection++;
                }
            }
        }
    }
    
    /**
     * Hace visible la ruta completa.
     */
    public void makeVisible() {
        isVisible = true;
        for (PathSegment segment : segments) {
            segment.makeVisible();
        }
    }
    
    /**
     * Hace invisible la ruta completa.
     */
    public void makeInvisible() {
        isVisible = false;
        for (PathSegment segment : segments) {
            segment.makeInvisible();
        }
    }
    
    /**
     * Obtiene la longitud de la ruta.
     * 
     * @return El número de segmentos en la ruta
     */
    public int getLength() {
        return length;
    }
    
    /**
     * Obtiene un segmento específico de la ruta.
     * 
     * @param position La posición del segmento (0-indexed)
     * @return El segmento en la posición especificada
     * @throws IndexOutOfBoundsException si la posición está fuera de rango
     */
    public PathSegment getSegment(int position) {
        if (position < 0 || position >= length) {
            throw new IndexOutOfBoundsException("Posición fuera de rango: " + position);
        }
        return segments.get(position);
    }
    
    /**
     * Obtiene las coordenadas de un segmento específico.
     * 
     * @param position La posición del segmento
     * @return Un arreglo con las coordenadas [x, y]
     */
    public int[] getSegmentCoordinates(int position) {
        PathSegment segment = getSegment(position);
        return segment.getCoordinates();
    }
    
    /**
     * Verifica si la ruta está visible.
     * 
     * @return true si la ruta está visible, false en caso contrario
     */
    public boolean isVisible() {
        return isVisible;
    }
    
    /**
     * Resalta un segmento específico de la ruta.
     * 
     * @param position La posición del segmento a resaltar
     */
    public void highlightSegment(int position) {
        if (position >= 0 && position < length) {
            segments.get(position).highlight();
        }
    }
    
    /**
     * Quita el resaltado de un segmento específico.
     * 
     * @param position La posición del segmento
     */
    public void unhighlightSegment(int position) {
        if (position >= 0 && position < length) {
            segments.get(position).unhighlight();
        }
    }
}
