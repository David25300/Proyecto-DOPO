/**
 * Representa un segmento individual de la ruta de seda.
 * Cada segmento es una unidad visual que forma parte del camino en espiral.
 * 
 * Principio de Responsabilidad Única: Solo maneja la visualización y 
 * propiedades de un segmento individual.
 * 
 * @author Santiago Cajamarca
 * @version 1.1
 */
public class PathSegment {
    
    private Rectangle visual;
    private int position;
    private int logicalX;  // cordenadas logicas
    private int logicalY;
    private int visualX;   
    private int visualY;  // cordenadas visuales (donde se dibujan)
    private int size;
    private boolean isOccupied;
    private String defaultColor = "yellow";
    private String highlightColor = "red";
    
    /**
     * Constructor de PathSegment.
     * 
     * @param position La posición del segmento en la ruta (0-indexed)
     * @param x La coordenada x lógica del segmento en el algoritmo espiral
     * @param y La coordenada y lógica del segmento en el algoritmo espiral
     * @param size El tamaño del segmento (ancho y alto)
     */
    public PathSegment(int position, int x, int y, int size) {
        this.position = position;
        this.logicalX = x;
        this.logicalY = y;
        this.size = size;
        this.isOccupied = false;
        
        // Calcular las coordenadas visuales reales
        this.visualX = x - -300; 
        this.visualY = y - -300;  
        
        // Crear la representación visual usando Rectangle 
        visual = new Rectangle();
        visual.changeSize(size, size);
        
        // Mover desde la posición inicial de Rectangle (70, 15) a la posición visual deseada
        int deltaX = visualX - 70;
        int deltaY = visualY - 15;
        
        if (deltaX != 0) {
            visual.moveHorizontal(deltaX);
        }
        if (deltaY != 0) {
            visual.moveVertical(deltaY);
        }
        
        visual.changeColor(defaultColor);
    }
    
    /**
     * Hace visible el segmento.
     */
    public void makeVisible() {
        visual.makeVisible();
    }
    
    /**
     * Hace invisible el segmento.
     */
    public void makeInvisible() {
        visual.makeInvisible();
    }
    
    /**
     * Resalta el segmento cambiando su color.
     */
    public void highlight() {
        visual.changeColor(highlightColor);
    }
    
    /**
     * Quita el resaltado del segmento volviendo al color por defecto.
     */
    public void unhighlight() {
        visual.changeColor(defaultColor);
    }
    
    /**
     * Obtiene las coordenadas VISUALES del segmento (donde realmente se dibuja).
     * Esta es la coordenada que deben usar los robots y tiendas.
     * 
     * @return Un arreglo con las coordenadas visuales [x, y]
     */
    public int[] getCoordinates() {
        return new int[]{visualX, visualY};
    }
    
    /**
     * Obtiene las coordenadas lógicas originales del algoritmo espiral.
     * Útil para debugging o cálculos internos.
     * 
     * @return Un arreglo con las coordenadas lógicas [x, y]
     */
    public int[] getLogicalCoordinates() {
        return new int[]{logicalX, logicalY};
    }
    
    /**
     * Obtiene la posición del segmento en la ruta.
     * 
     * @return La posición del segmento
     */
    public int getPosition() {
        return position;
    }
    
    /**
     * Obtiene la coordenada x visual del centro del segmento.
     * 
     * @return La coordenada x del centro
     */
    public int getCenterX() {
        return visualX + size / 2;
    }
    
    /**
     * Obtiene la coordenada y visual del centro del segmento.
     * 
     * @return La coordenada y del centro
     */
    public int getCenterY() {
        return visualY + size / 2;
    }
    
    /**
     * Marca el segmento como ocupado.
     * 
     * @param occupied true si está ocupado, false en caso contrario
     */
    public void setOccupied(boolean occupied) {
        this.isOccupied = occupied;
        if (occupied) {
            visual.changeColor("orange");
        } else {
            visual.changeColor(defaultColor);
        }
    }
    
    /**
     * Verifica si el segmento está ocupado.
     * 
     * @return true si está ocupado, false en caso contrario
     */
    public boolean isOccupied() {
        return isOccupied;
    }
    
    /**
     * Obtiene el tamaño del segmento.
     * 
     * @return El tamaño del segmento
     */
    public int getSize() {
        return size;
    }
    
    /**
     * Obtiene las coordenadas para posicionar elementos encima del segmento.
     * Incluye un offset para centrar mejor los elementos. 
     * 
     * @return Un arreglo con las coordenadas centradas [x, y]
     */
    public int[] getCenteredCoordinates() {
        return new int[]{getCenterX() - 10, getCenterY() - 10};
    }
}