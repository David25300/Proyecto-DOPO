import java.util.*;

/**
 * Representa un robot que puede moverse por la ruta de seda - CICLO 2.
 * Cada robot puede recoger tenges de las tiendas, con un costo de 1 tenge por segmento movido.
 * Incluye soporte para posiciones originales ICPC y registro de movimientos.
 * 
 * Principio de Responsabilidad Única: Solo maneja el estado y 
 * comportamiento de un robot individual.
 * 
 * @author Tu Nombre
 * @version 3.0 - Ciclo 2
 */
public class Robot {
    
    private static int nextId = 1;
    private int id;
    private int currentPosition;
    private int initialPosition;
    private int originalInitialPosition;  // NUEVO - Posición original del ICPC
    private int tengesCollected;
    private int costIncurred;
    private Triangle visual;
    private String color;
    private boolean isCurrentlyVisible;
    private static int colorIndex = 0;
    private static final String[] COLORS = {"green", "magenta", "blue", "red", "cyan", "orange"};
    
    // NUEVO para Ciclo 2 - Registro de movimientos
    private List<MovementRecord> movementHistory;
    private boolean shouldBlink; // Para el robot con mayor ganancia
    private Thread blinkThread;  // Para manejar el parpadeo
    
    /**
     * Constructor de Robot.
     * 
     * @param initialPosition La posición inicial del robot en la ruta
     * @param maxCapacity La capacidad máxima (no usado en este problema, pero mantenido por extensibilidad)
     */
    public Robot(int initialPosition, int maxCapacity) {
        this.id = nextId++;
        this.initialPosition = initialPosition;
        this.originalInitialPosition = initialPosition; // Por defecto, igual a la posición mapeada
        this.currentPosition = initialPosition;
        this.tengesCollected = 0;
        this.costIncurred = 0;
        this.isCurrentlyVisible = false;
        this.shouldBlink = false;
        this.movementHistory = new ArrayList<>();
        
        // Asignar un color único a cada robot
        this.color = COLORS[colorIndex % COLORS.length];
        colorIndex++;
        
        // Crear la representación visual
        visual = new Triangle();
        visual.changeSize(20, 20);
        visual.changeColor(color);
    }
    
    /**
     * Establece la posición inicial original del problema ICPC.
     * NUEVO - Requisito 10: Soporte ICPC
     * 
     * @param originalPosition La posición original del ICPC
     */
    public void setOriginalInitialPosition(int originalPosition) {
        this.originalInitialPosition = originalPosition;
    }
    
    /**
     * Obtiene la posición inicial original del problema ICPC.
     * NUEVO - Requisito 10: Soporte ICPC
     * 
     * @return La posición original del ICPC
     */
    public int getOriginalInitialPosition() {
        return originalInitialPosition;
    }
    
    /**
     * Registro de un movimiento individual.
     * NUEVO - Requisito 13: Registrar ganancias por movimiento
     */
    public static class MovementRecord {
        private int fromPosition;
        private int toPosition;
        private int steps;
        private int cost;
        private int tengesCollected;
        private int netProfit;
        private long timestamp;
        
        public MovementRecord(int from, int to, int steps, int cost, int collected, int profit) {
            this.fromPosition = from;
            this.toPosition = to;
            this.steps = steps;
            this.cost = cost;
            this.tengesCollected = collected;
            this.netProfit = profit;
            this.timestamp = System.currentTimeMillis();
        }
        
        // Getters
        public int getFromPosition() { return fromPosition; }
        public int getToPosition() { return toPosition; }
        public int getSteps() { return steps; }
        public int getCost() { return cost; }
        public int getTengesCollected() { return tengesCollected; }
        public int getNetProfit() { return netProfit; }
        public long getTimestamp() { return timestamp; }
        
        @Override
        public String toString() {
            return String.format("Movimiento: %d→%d (%d pasos), Costo:%d, Recogió:%d, Ganancia:%d",
                fromPosition, toPosition, steps, cost, tengesCollected, netProfit);
        }
    }
    
    /**
     * Posiciona el robot visualmente en las coordenadas especificadas.
     * Mantiene el estado de visibilidad.
     * 
     * @param x La coordenada x
     * @param y La coordenada y
     */
    public void setVisualPosition(int x, int y) {
        // Detener parpadeo temporalmente
        stopBlinking();
        
        // Primero hacer invisible si estaba visible
        if (visual != null) {
            visual.makeInvisible();
        }
        
        // Recrear el visual en la posición correcta
        visual = new Triangle();
        visual.changeSize(20, 20);
        visual.changeColor(color);
        
        // Calcular la diferencia desde la posición por defecto del Triangle (140, 15)
        int deltaX = x - 140;
        int deltaY = y - 15;
        
        // Mover a la posición deseada
        if (deltaX != 0) {
            visual.moveHorizontal(deltaX);
        }
        if (deltaY != 0) {
            visual.moveVertical(deltaY);
        }
        
        // Si el robot debe estar visible, hacerlo visible
        if (isCurrentlyVisible) {
            visual.makeVisible();
            
            // Reanudar parpadeo si corresponde
            if (shouldBlink) {
                startBlinking();
            }
        }
    }
    
    /**
     * Mueve el robot a una nueva posición en la ruta.
     * MODIFICADO - Ciclo 2: Registra el movimiento
     * 
     * @param newPosition La nueva posición
     * @param steps Número de pasos dados
     * @param cost Costo del movimiento
     * @param tengesCollected Tenges recogidos en este movimiento
     */
    public void moveTo(int newPosition, int steps, int cost, int tengesCollected) {
        int oldPosition = this.currentPosition;
        
        // Registrar el movimiento
        int netProfit = tengesCollected - cost;
        MovementRecord movement = new MovementRecord(
            oldPosition, newPosition, steps, cost, tengesCollected, netProfit
        );
        movementHistory.add(movement);
        
        // Actualizar posición
        this.currentPosition = newPosition;
    }
    
    /**
     * Sobrecarga para compatibilidad con código existente.
     * 
     * @param newPosition La nueva posición
     */
    public void moveTo(int newPosition) {
        moveTo(newPosition, 0, 0, 0); // Sin registro detallado
    }
    
    /**
     * Retorna el robot a su posición inicial.
     * Usado para el requisito de return robots.
     */
    public void returnToInitialPosition() {
        this.currentPosition = this.initialPosition;
        // No registrar este movimiento como un movimiento normal
    }
    
    /**
     * Añade costo al movimiento del robot.
     * Cada segmento movido cuesta 1 tenge.
     * 
     * @param cost El costo a añadir
     */
    public void addCost(int cost) {
        this.costIncurred += cost;
    }
    
    /**
     * Establece el costo incurrido.
     * 
     * @param cost El nuevo costo
     */
    public void setCostIncurred(int cost) {
        this.costIncurred = cost;
    }
    
    /**
     * El robot recoge tenges.
     * 
     * @param amount La cantidad de tenges recogidos
     */
    public void collectTenges(int amount) {
        this.tengesCollected += amount;
    }
    
    /**
     * Reinicia los tenges recogidos.
     */
    public void resetTengesCollected() {
        this.tengesCollected = 0;
    }
    
    /**
     * Limpia el historial de movimientos.
     * NUEVO - Requisito 13: Para reset de estadísticas
     */
    public void clearMovementHistory() {
        this.movementHistory.clear();
    }
    
    /**
     * Obtiene el historial completo de movimientos.
     * NUEVO - Requisito 13: Consultar ganancias por movimiento
     * 
     * @return Lista inmutable del historial de movimientos
     */
    public List<MovementRecord> getMovementHistory() {
        return Collections.unmodifiableList(movementHistory);
    }
    
    /**
     * Obtiene las ganancias de cada movimiento como lista.
     * NUEVO - Requisito 13: Consultar ganancias por movimiento
     * 
     * @return Lista de ganancias netas por movimiento
     */
    public List<Integer> getMovementProfits() {
        List<Integer> profits = new ArrayList<>();
        for (MovementRecord record : movementHistory) {
            profits.add(record.getNetProfit());
        }
        return profits;
    }
    
    /**
     * Obtiene un resumen detallado de todos los movimientos.
     * NUEVO - Requisito 13: Información detallada
     * 
     * @return String con resumen de movimientos
     */
    public String getMovementSummary() {
        if (movementHistory.isEmpty()) {
            return "Robot " + id + ": Sin movimientos registrados";
        }
        
        StringBuilder summary = new StringBuilder();
        summary.append("=== Resumen de Movimientos - Robot ").append(id).append(" ===\n");
        
        int totalMovements = movementHistory.size();
        int totalProfit = movementHistory.stream().mapToInt(MovementRecord::getNetProfit).sum();
        int totalCost = movementHistory.stream().mapToInt(MovementRecord::getCost).sum();
        int totalCollected = movementHistory.stream().mapToInt(MovementRecord::getTengesCollected).sum();
        
        summary.append("Total movimientos: ").append(totalMovements).append("\n");
        summary.append("Ganancia total: ").append(totalProfit).append("\n");
        summary.append("Costo total: ").append(totalCost).append("\n");
        summary.append("Tenges recogidos: ").append(totalCollected).append("\n");
        summary.append("\nDetalle por movimiento:\n");
        
        for (int i = 0; i < movementHistory.size(); i++) {
            summary.append("  ").append(i + 1).append(". ")
                   .append(movementHistory.get(i).toString()).append("\n");
        }
        
        return summary.toString();
    }
    
    /**
     * Activa el parpadeo del robot.
     * NUEVO - Requisito de usabilidad: robot con mayor ganancia debe parpadear
     */
    public void startBlinking() {
        if (shouldBlink || !isCurrentlyVisible) {
            return; // Ya está parpadeando o no es visible
        }
        
        shouldBlink = true;
        
        blinkThread = new Thread(() -> {
            String originalColor = color;
            boolean isOriginalColor = true;
            
            while (shouldBlink && isCurrentlyVisible) {
                try {
                    if (isOriginalColor) {
                        visual.changeColor("yellow"); // Color de parpadeo
                    } else {
                        visual.changeColor(originalColor);
                    }
                    isOriginalColor = !isOriginalColor;
                    Thread.sleep(500); // Parpadeo cada 500ms
                } catch (InterruptedException e) {
                    break;
                }
            }
            
            // Restaurar color original al terminar
            if (isCurrentlyVisible) {
                visual.changeColor(originalColor);
            }
        });
        
        blinkThread.start();
    }
    
    /**
     * Detiene el parpadeo del robot.
     * NUEVO - Requisito de usabilidad: control del parpadeo
     */
    public void stopBlinking() {
        shouldBlink = false;
        
        if (blinkThread != null && blinkThread.isAlive()) {
            blinkThread.interrupt();
            try {
                blinkThread.join(100); // Esperar máximo 100ms
            } catch (InterruptedException e) {
                // Ignorar
            }
        }
        
        // Restaurar color original
        if (isCurrentlyVisible && visual != null) {
            visual.changeColor(color);
        }
    }
    
    /**
     * Verifica si el robot está parpadeando.
     * 
     * @return true si está parpadeando, false en caso contrario
     */
    public boolean isBlinking() {
        return shouldBlink;
    }
    
    /**
     * Hace visible el robot.
     */
    public void makeVisible() {
        isCurrentlyVisible = true;
        visual.makeVisible();
        
        // Si debe parpadear, iniciar parpadeo
        if (shouldBlink) {
            startBlinking();
        }
    }
    
    /**
     * Hace invisible el robot.
     */
    public void makeInvisible() {
        stopBlinking(); // Detener parpadeo antes de hacer invisible
        isCurrentlyVisible = false;
        visual.makeInvisible();
    }
    
    /**
     * Verifica si el robot está visible.
     * 
     * @return true si está visible, false en caso contrario
     */
    public boolean isVisible() {
        return isCurrentlyVisible;
    }
    
    /**
     * Obtiene el ID del robot.
     * 
     * @return El ID único del robot
     */
    public int getId() {
        return id;
    }
    
    /**
     * Obtiene la posición actual del robot.
     * 
     * @return La posición actual
     */
    public int getCurrentPosition() {
        return currentPosition;
    }
    
    /**
     * Obtiene la posición inicial del robot.
     * 
     * @return La posición inicial
     */
    public int getInitialPosition() {
        return initialPosition;
    }
    
    /**
     * Obtiene los tenges recogidos por el robot.
     * 
     * @return La cantidad de tenges recogidos
     */
    public int getTengesCollected() {
        return tengesCollected;
    }
    
    /**
     * Obtiene el costo incurrido por el robot en movimientos.
     * 
     * @return El costo total incurrido
     */
    public int getCostIncurred() {
        return costIncurred;
    }
    
    /**
     * Calcula la ganancia neta del robot.
     * 
     * @return La ganancia (tenges recogidos - costo incurrido)
     */
    public int getNetProfit() {
        return tengesCollected - costIncurred;
    }
    
    /**
     * Obtiene el color del robot.
     * 
     * @return El color del robot
     */
    public String getColor() {
        return color;
    }
    
    /**
     * Obtiene información del robot como string.
     * MODIFICADO - Ciclo 2: Incluye información adicional
     * 
     * @return String con la información del robot
     */
    public String getInfo() {
        String blinkStatus = shouldBlink ? " (PARPADEANDO)" : "";
        return String.format("Robot %d: Pos=%d (orig=%d), Tenges=%d, Costo=%d, Ganancia=%d, Movimientos=%d%s", 
                           id, currentPosition, originalInitialPosition, tengesCollected, costIncurred, 
                           getNetProfit(), movementHistory.size(), blinkStatus);
    }
}