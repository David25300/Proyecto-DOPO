import java.util.*;

/**
 * Gestiona la secuencia de días y eventos en el simulador de la Ruta de Seda.
 * Maneja la lógica de procesamiento de entrada del problema ICPC.
 * 
 * Principio de Responsabilidad Única: Solo maneja la secuencia temporal de eventos
 * Principio de Inversión de Dependencias: Depende de abstracciones (SilkRoadEvent)
 * 
 * @author Tu Nombre
 * @version 1.0
 */
public class DayManager {
    
    private List<List<SilkRoadEvent>> days;
    private int currentDay;
    private boolean isInitialized;
    
    /**
     * Constructor del DayManager.
     */
    public DayManager() {
        this.days = new ArrayList<>();
        this.currentDay = 0;
        this.isInitialized = false;
    }
    
    /**
     * Inicializa el manager con la entrada del problema ICPC.
     * Parsea la entrada y crea la secuencia de días con sus eventos.
     * 
     * @param icpcInput Array de strings representando la entrada del ICPC
     * @throws IllegalArgumentException si la entrada es inválida
     */
    public void initializeFromICPCInput(String[] icpcInput) {
        if (icpcInput == null || icpcInput.length == 0) {
            throw new IllegalArgumentException("La entrada no puede estar vacía");
        }
        
        try {
            int n = Integer.parseInt(icpcInput[0]);
            
            if (n <= 0 || icpcInput.length != n + 1) {
                throw new IllegalArgumentException("Número de días inválido o entrada incompleta");
            }
            
            days.clear();
            List<SilkRoadEvent> currentDayEvents = new ArrayList<>();
            
            for (int i = 1; i <= n; i++) {
                String[] parts = icpcInput[i].trim().split("\\s+");
                
                if (parts.length < 2) {
                    throw new IllegalArgumentException("Formato inválido en línea " + i);
                }
                
                int eventType = Integer.parseInt(parts[0]);
                int position = Integer.parseInt(parts[1]);
                
                SilkRoadEvent event;
                
                if (eventType == 1) {
                    // Añadir robot
                    event = new AddRobotEvent(days.size(), position);
                } else if (eventType == 2) {
                    // Añadir tienda
                    if (parts.length < 3) {
                        throw new IllegalArgumentException("Falta cantidad de tenges en línea " + i);
                    }
                    int tenges = Integer.parseInt(parts[2]);
                    event = new AddStoreEvent(days.size(), position, tenges);
                } else {
                    throw new IllegalArgumentException("Tipo de evento inválido: " + eventType);
                }
                
                currentDayEvents.add(event);
                
                // Cada evento termina con un reboot implícito
                currentDayEvents.add(new RebootEvent(days.size()));
                
                // Completar el día
                days.add(new ArrayList<>(currentDayEvents));
                currentDayEvents.clear();
            }
            
            currentDay = 0;
            isInitialized = true;
            
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Error de formato numérico en la entrada: " + e.getMessage());
        } catch (Exception e) {
            throw new IllegalArgumentException("Error procesando entrada ICPC: " + e.getMessage());
        }
    }
    
    /**
     * Inicializa el manager con eventos personalizados.
     * Permite crear secuencias de eventos de forma programática.
     * 
     * @param customEvents Lista de listas de eventos por día
     */
    public void initializeFromEvents(List<List<SilkRoadEvent>> customEvents) {
        if (customEvents == null) {
            throw new IllegalArgumentException("La lista de eventos no puede ser null");
        }
        
        days.clear();
        for (List<SilkRoadEvent> dayEvents : customEvents) {
            days.add(new ArrayList<>(dayEvents));
        }
        
        currentDay = 0;
        isInitialized = !days.isEmpty();
    }
    
    /**
     * Ejecuta todos los eventos de un día específico.
     * 
     * @param simulator El simulador donde ejecutar los eventos
     * @param day El día a ejecutar
     * @return true si todos los eventos se ejecutaron exitosamente
     * @throws IndexOutOfBoundsException si el día está fuera de rango
     */
    public boolean executeDayEvents(SilkRoad simulator, int day) {
        if (!isInitialized) {
            throw new IllegalStateException("DayManager no ha sido inicializado");
        }
        
        if (day < 0 || day >= days.size()) {
            throw new IndexOutOfBoundsException("Día fuera de rango: " + day);
        }
        
        List<SilkRoadEvent> dayEvents = days.get(day);
        boolean allSuccessful = true;
        
        for (SilkRoadEvent event : dayEvents) {
            try {
                boolean success = event.execute(simulator);
                if (!success) {
                    allSuccessful = false;
                    System.err.println("Falló la ejecución de: " + event.getDescription());
                }
            } catch (Exception e) {
                allSuccessful = false;
                System.err.println("Error ejecutando evento: " + event.getDescription() + " - " + e.getMessage());
            }
        }
        
        return allSuccessful;
    }
    
    /**
     * Ejecuta el siguiente día en la secuencia.
     * 
     * @param simulator El simulador donde ejecutar los eventos
     * @return true si se ejecutó exitosamente, false si no hay más días
     */
    public boolean executeNextDay(SilkRoad simulator) {
        if (!hasMoreDays()) {
            return false;
        }
        
        boolean success = executeDayEvents(simulator, currentDay);
        currentDay++;
        return success;
    }
    
    /**
     * Ejecuta todos los días restantes en secuencia.
     * 
     * @param simulator El simulador donde ejecutar los eventos
     * @return El número de días ejecutados exitosamente
     */
    public int executeAllDays(SilkRoad simulator) {
        int successfulDays = 0;
        
        while (hasMoreDays()) {
            if (executeNextDay(simulator)) {
                successfulDays++;
            }
        }
        
        return successfulDays;
    }
    
    /**
     * Verifica si hay más días por ejecutar.
     * 
     * @return true si hay más días, false en caso contrario
     */
    public boolean hasMoreDays() {
        return isInitialized && currentDay < days.size();
    }
    
    /**
     * Obtiene el número total de días.
     * 
     * @return El número total de días
     */
    public int getTotalDays() {
        return isInitialized ? days.size() : 0;
    }
    
    /**
     * Obtiene el día actual.
     * 
     * @return El día actual (0-indexed)
     */
    public int getCurrentDay() {
        return currentDay;
    }
    
    /**
     * Reinicia la ejecución al día 0.
     */
    public void reset() {
        currentDay = 0;
    }
    
    /**
     * Obtiene los eventos de un día específico.
     * 
     * @param day El día del cual obtener los eventos
     * @return Lista de eventos del día especificado
     * @throws IndexOutOfBoundsException si el día está fuera de rango
     */
    public List<SilkRoadEvent> getDayEvents(int day) {
        if (!isInitialized || day < 0 || day >= days.size()) {
            throw new IndexOutOfBoundsException("Día fuera de rango: " + day);
        }
        
        return new ArrayList<>(days.get(day)); // Copia defensiva
    }
    
    /**
     * Obtiene una descripción de todos los días y sus eventos.
     * 
     * @return String con la descripción completa
     */
    public String getFullDescription() {
        if (!isInitialized) {
            return "DayManager no inicializado";
        }
        
        StringBuilder description = new StringBuilder();
        description.append("=== Secuencia de Días ===\n");
        description.append("Total de días: ").append(days.size()).append("\n");
        description.append("Día actual: ").append(currentDay).append("\n\n");
        
        for (int day = 0; day < days.size(); day++) {
            description.append("--- Día ").append(day).append(" ---\n");
            List<SilkRoadEvent> dayEvents = days.get(day);
            
            for (SilkRoadEvent event : dayEvents) {
                description.append("  ").append(event.getDescription()).append("\n");
            }
            description.append("\n");
        }
        
        return description.toString();
    }
    
    /**
     * Verifica si el manager está inicializado.
     * 
     * @return true si está inicializado, false en caso contrario
     */
    public boolean isInitialized() {
        return isInitialized;
    }
}