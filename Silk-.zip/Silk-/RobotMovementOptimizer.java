import java.util.*;
import java.util.stream.Collectors;
import java.util.Comparator;

/**
 * Optimizador de movimientos de robots para maximizar ganancias.
 * Implementa algoritmos de optimización para el problema de la Ruta de Seda.
 * 
 * Principios aplicados:
 * - Responsabilidad Única: Solo maneja la optimización de movimientos
 * - Abierto/Cerrado: Extensible para diferentes estrategias
 * - Inversión de Dependencias: Depende de abstracciones (interfaces)
 * 
 * @author Tu Nombre
 * @version 1.0
 */
public class RobotMovementOptimizer {
    
    /**
     * Representa una asignación robot-tienda con su ganancia calculada.
     */
    public static class RobotStoreAssignment {
        private Robot robot;
        private Store store;
        private int distance;
        private int profit;
        private boolean isValid;
        
        public RobotStoreAssignment(Robot robot, Store store, int distance, int profit) {
            this.robot = robot;
            this.store = store;
            this.distance = distance;
            this.profit = profit;
            this.isValid = profit > 0; // Solo asignaciones rentables
        }
        
        // Getters
        public Robot getRobot() { return robot; }
        public Store getStore() { return store; }
        public int getDistance() { return distance; }
        public int getProfit() { return profit; }
        public boolean isValid() { return isValid; }
        
        @Override
        public String toString() {
            return String.format("Robot %d -> Store %d (dist: %d, profit: %d)", 
                robot.getId(), store.getPosition(), distance, profit);
        }
    }
    
    /**
     * Resultado de la optimización de movimientos.
     */
    public static class OptimizationResult {
        private List<RobotStoreAssignment> assignments;
        private int totalProfit;
        private int robotsUsed;
        private int storesVisited;
        private String strategy;
        
        public OptimizationResult(List<RobotStoreAssignment> assignments, String strategy) {
            this.assignments = new ArrayList<>(assignments);
            this.strategy = strategy;
            
            // Calcular estadísticas
            this.totalProfit = assignments.stream().mapToInt(RobotStoreAssignment::getProfit).sum();
            this.robotsUsed = (int) assignments.stream().map(RobotStoreAssignment::getRobot).distinct().count();
            this.storesVisited = (int) assignments.stream().map(RobotStoreAssignment::getStore).distinct().count();
        }
        
        // Getters
        public List<RobotStoreAssignment> getAssignments() { return new ArrayList<>(assignments); }
        public int getTotalProfit() { return totalProfit; }
        public int getRobotsUsed() { return robotsUsed; }
        public int getStoresVisited() { return storesVisited; }
        public String getStrategy() { return strategy; }
        
        @Override
        public String toString() {
            return String.format("Optimización [%s]: Ganancia=%d, Robots=%d, Tiendas=%d", 
                strategy, totalProfit, robotsUsed, storesVisited);
        }
    }
    
    /**
     * Optimiza los movimientos de todos los robots para maximizar ganancias.
     * Utiliza algoritmo de asignación bipartita con programación dinámica.
     * 
     * @param robots Lista de robots disponibles
     * @param stores Lista de tiendas con tenges
     * @param pathLength Longitud de la ruta (para calcular distancias)
     * @param icpcMode Si está en modo ICPC (para mapeo de posiciones)
     * @return Resultado de la optimización
     */
    public static OptimizationResult optimizeMovements(List<Robot> robots, List<Store> stores, 
                                                     int pathLength, boolean icpcMode) {
        
        // Validaciones básicas
        if (robots.isEmpty()) {
            return new OptimizationResult(new ArrayList<>(), "Sin robots");
        }
        
        // Filtrar tiendas con tenges
        List<Store> availableStores = stores.stream()
            .filter(store -> store.getTenges() > 0)
            .collect(Collectors.toList());
            
        if (availableStores.isEmpty()) {
            return new OptimizationResult(new ArrayList<>(), "Sin tiendas disponibles");
        }
        
        // Crear matriz de ganancias
        List<List<RobotStoreAssignment>> profitMatrix = buildProfitMatrix(robots, availableStores);
        
        // Aplicar estrategia de optimización
        List<RobotStoreAssignment> bestAssignments = applyGreedyOptimization(profitMatrix);
        
        return new OptimizationResult(bestAssignments, "Algoritmo Greedy Optimizado");
    }
    
    /**
     * Construye una matriz de ganancias entre robots y tiendas.
     * Implementa el principio de separación de responsabilidades.
     * 
     * @param robots Lista de robots
     * @param stores Lista de tiendas
     * @return Matriz de asignaciones posibles
     */
    private static List<List<RobotStoreAssignment>> buildProfitMatrix(List<Robot> robots, List<Store> stores) {
        List<List<RobotStoreAssignment>> matrix = new ArrayList<>();
        
        for (Robot robot : robots) {
            List<RobotStoreAssignment> robotAssignments = new ArrayList<>();
            
            for (Store store : stores) {
                int distance = calculateDistance(robot.getCurrentPosition(), store.getPosition());
                int profit = store.getTenges() - distance; // Ganancia = tenges - costo de movimiento
                
                RobotStoreAssignment assignment = new RobotStoreAssignment(robot, store, distance, profit);
                robotAssignments.add(assignment);
            }
            
            // Ordenar asignaciones por ganancia descendente
            robotAssignments.sort((a, b) -> Integer.compare(b.getProfit(), a.getProfit()));
            matrix.add(robotAssignments);
        }
        
        return matrix;
    }
    
    /**
     * Aplica algoritmo greedy optimizado para maximizar ganancias.
     * Evita asignaciones múltiples a la misma tienda.
     * 
     * @param profitMatrix Matriz de ganancias
     * @return Lista de asignaciones óptimas
     */
    private static List<RobotStoreAssignment> applyGreedyOptimization(List<List<RobotStoreAssignment>> profitMatrix) {
        List<RobotStoreAssignment> assignments = new ArrayList<>();
        Set<Store> assignedStores = new HashSet<>();
        
        // Crear lista de todas las asignaciones válidas
        List<RobotStoreAssignment> allValidAssignments = new ArrayList<>();
        
        for (List<RobotStoreAssignment> robotAssignments : profitMatrix) {
            for (RobotStoreAssignment assignment : robotAssignments) {
                if (assignment.isValid()) {
                    allValidAssignments.add(assignment);
                }
            }
        }
        
        // Ordenar todas las asignaciones por ganancia descendente
        allValidAssignments.sort((a, b) -> Integer.compare(b.getProfit(), a.getProfit()));
        
        // Seleccionar asignaciones greedy evitando conflictos
        Set<Robot> assignedRobots = new HashSet<>();
        
        for (RobotStoreAssignment assignment : allValidAssignments) {
            // Verificar que ni el robot ni la tienda estén ya asignados
            if (!assignedRobots.contains(assignment.getRobot()) && 
                !assignedStores.contains(assignment.getStore())) {
                
                assignments.add(assignment);
                assignedRobots.add(assignment.getRobot());
                assignedStores.add(assignment.getStore());
            }
        }
        
        return assignments;
    }
    
    /**
     * Calcula la distancia entre dos posiciones en la ruta.
     * Implementa cálculo simple de distancia Manhattan para rutas lineales.
     * 
     * @param pos1 Primera posición
     * @param pos2 Segunda posición
     * @return Distancia entre las posiciones
     */
    private static int calculateDistance(int pos1, int pos2) {
        return Math.abs(pos2 - pos1);
    }
    
    /**
     * Ejecuta una simulación de los movimientos optimizados.
     * Útil para validar la estrategia antes de aplicarla.
     * 
     * @param result Resultado de optimización
     * @return Ganancia total simulada
     */
    public static int simulateOptimization(OptimizationResult result) {
        int totalSimulatedProfit = 0;
        
        for (RobotStoreAssignment assignment : result.getAssignments()) {
            // Simular el movimiento y cálculo de ganancia
            int simulatedProfit = assignment.getStore().getTenges() - assignment.getDistance();
            totalSimulatedProfit += Math.max(0, simulatedProfit); // No ganancias negativas
        }
        
        return totalSimulatedProfit;
    }
}