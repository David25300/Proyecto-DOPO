/**
 * Representa un evento que ocurre en la ruta de seda.
 * Abstracción base para diferentes tipos de eventos.
 * 
 * Principio de Responsabilidad Única: Solo define la estructura de un evento
 * Principio Abierto/Cerrado: Extensible para nuevos tipos de eventos
 * 
 * @author Tu Nombre
 * @version 1.0
 */
public abstract class SilkRoadEvent {
    
    protected int day;
    protected int position;
    
    /**
     * Constructor base para eventos.
     * 
     * @param day El día en que ocurre el evento
     * @param position La posición en la ruta donde ocurre
     */
    public SilkRoadEvent(int day, int position) {
        this.day = day;
        this.position = position;
    }
    
    /**
     * Ejecuta el evento en el simulador.
     * 
     * @param simulator El simulador donde se ejecuta el evento
     * @return true si el evento se ejecutó exitosamente, false en caso contrario
     */
    public abstract boolean execute(SilkRoad simulator);
    
    /**
     * Obtiene el día del evento.
     * 
     * @return El día del evento
     */
    public int getDay() {
        return day;
    }
    
    /**
     * Obtiene la posición del evento.
     * 
     * @return La posición del evento
     */
    public int getPosition() {
        return position;
    }
    
    /**
     * Obtiene una descripción del evento.
     * 
     * @return Descripción del evento
     */
    public abstract String getDescription();
}

/**
 * Evento para añadir un robot a la ruta.
 * 
 * @author Tu Nombre
 * @version 1.0
 */
class AddRobotEvent extends SilkRoadEvent {
    
    public AddRobotEvent(int day, int position) {
        super(day, position);
    }
    
    @Override
    public boolean execute(SilkRoad simulator) {
        int robotId = simulator.addRobot(position);
        return robotId != -1;
    }
    
    @Override
    public String getDescription() {
        return String.format("Día %d: Añadir robot en posición %d", day, position);
    }
}

/**
 * Evento para añadir una tienda a la ruta.
 * 
 * @author Tu Nombre
 * @version 1.0
 */
class AddStoreEvent extends SilkRoadEvent {
    
    private int tenges;
    
    public AddStoreEvent(int day, int position, int tenges) {
        super(day, position);
        this.tenges = tenges;
    }
    
    @Override
    public boolean execute(SilkRoad simulator) {
        return simulator.addStore(position, tenges);
    }
    
    @Override
    public String getDescription() {
        return String.format("Día %d: Añadir tienda en posición %d con %d tenges", day, position, tenges);
    }
    
    /**
     * Obtiene la cantidad de tenges de la tienda.
     * 
     * @return La cantidad de tenges
     */
    public int getTenges() {
        return tenges;
    }
}

/**
 * Evento de reinicio (reboot) que marca el inicio de un nuevo día.
 * 
 * @author Tu Nombre
 * @version 1.0
 */
class RebootEvent extends SilkRoadEvent {
    
    public RebootEvent(int day) {
        super(day, -1); // No tiene posición específica
    }
    
    @Override
    public boolean execute(SilkRoad simulator) {
        simulator.reboot();
        return true;
    }
    
    @Override
    public String getDescription() {
        return String.format("Día %d: Reboot (inicio del día)", day);
    }
}