import java.util.*;
import java.util.stream.Collectors;
import java.util.Comparator;

/**
 * Clase principal del simulador de la Ruta de la Seda - CICLO 2.
 * Gestiona la creación y manipulación de una ruta comercial con tiendas y robots.
 * Incluye soporte para entrada del problema ICPC y gestión de días/eventos.
 * 
 * @author Tu Nombre
 * @version 3.0 - Ciclo 2
 */
public class SilkRoad {
    
    private SilkPath path;
    private List<Store> stores;
    private List<Robot> robots;
    private boolean isVisible;
    private double totalProfit;
    private double maxPossibleProfit;
    private ProfitProgressBar progressBar;
    private DayManager dayManager; // Nuevo para Ciclo 2
    private boolean icpcMode; // Indica si se está usando modo ICPC
    
    // Configuración de la barra de progreso
    private static final int PROGRESS_BAR_X = 50;
    private static final int PROGRESS_BAR_Y = 20;
    private static final int PROGRESS_BAR_WIDTH = 300;
    private static final int PROGRESS_BAR_HEIGHT = 25;
    
    /**
     * Constructor de SilkRoad.
     * Inicializa una ruta de seda vacía con barra de progreso.
     */
    public SilkRoad() {
        this.stores = new ArrayList<>();
        this.robots = new ArrayList<>();
        this.isVisible = true;
        this.totalProfit = 0.0;
        this.maxPossibleProfit = 0.0;
        this.dayManager = new DayManager();
        this.icpcMode = false;
        
        // Inicializar la barra de progreso
        this.progressBar = new ProfitProgressBar(
            PROGRESS_BAR_X, PROGRESS_BAR_Y, 
            PROGRESS_BAR_WIDTH, PROGRESS_BAR_HEIGHT
        );
    }
    
    /**
     * Crea una nueva ruta de seda con la longitud especificada (método original).
     * La ruta tomará forma de espiral cuadrada si es necesario.
     * Requisito 1: create (original)
     * 
     * @param length La longitud de la ruta de seda (número de segmentos)
     * @throws IllegalArgumentException si la longitud es menor o igual a 0
     */
    public void create(int length) {
        create(length, null);
    }
    
    /**
     * Crea una nueva ruta de seda con entrada del problema ICPC.
     * EXTENSIÓN - Requisito 10: create con entrada ICPC
     * 
     * @param length La longitud física de la ruta (número de segmentos máximos)
     * @param icpcInput Entrada del problema ICPC (null para modo tradicional)
     * @throws IllegalArgumentException si los parámetros son inválidos
     */
    public void create(int length, String[] icpcInput) {
        if (length <= 0) {
            throw new IllegalArgumentException("La longitud debe ser mayor que 0");
        }
        
        // Limpiar elementos anteriores si existen
        if (path != null) {
            makeInvisible();
            stores.clear();
            robots.clear();
        }
        
        // Determinar si se necesita mapear posiciones del ICPC a índices de ruta
        int routeLength = length;
        
        if (icpcInput != null) {
            // Modo ICPC: parsear entrada y determinar rango de posiciones
            icpcMode = true;
            routeLength = determineRouteLength(icpcInput, length);
            
            try {
                dayManager.initializeFromICPCInput(icpcInput);
                showMessage("Ruta ICPC inicializada con " + dayManager.getTotalDays() + " días de eventos");
            } catch (Exception e) {
                throw new IllegalArgumentException("Error procesando entrada ICPC: " + e.getMessage());
            }
        } else {
            // Modo tradicional
            icpcMode = false;
            dayManager = new DayManager(); // Resetear
        }
        
        // Crear la ruta con el patrón de espiral
        this.path = new SilkPath(routeLength);
        
        // Reiniciar las ganancias
        totalProfit = 0.0;
        maxPossibleProfit = 0.0;
        updateProgressBar();
        
        // Si el simulador está visible, dibujar la ruta
        if (isVisible) {
            path.makeVisible();
            progressBar.makeVisible();
        }
        
        showMessage("Ruta creada - Longitud: " + routeLength + 
                   (icpcMode ? " (Modo ICPC)" : " (Modo tradicional)"));
    }
    
    /**
     * Mueve todos los robots de forma optimizada para maximizar ganancias.
     * NUEVO - Requisito 11: Movimientos optimizados
     * 
     * @return Resultado de la optimización con detalles de movimientos
     */
    public RobotMovementOptimizer.OptimizationResult optimizeRobotMovements() {
        if (path == null) {
            showMessage("Error: La ruta no ha sido creada aún");
            return new RobotMovementOptimizer.OptimizationResult(new ArrayList<>(), "Ruta no creada");
        }
        
        if (robots.isEmpty()) {
            showMessage("No hay robots para mover");
            return new RobotMovementOptimizer.OptimizationResult(new ArrayList<>(), "Sin robots");
        }
        
        // Aplicar algoritmo de optimización
        RobotMovementOptimizer.OptimizationResult result = 
            RobotMovementOptimizer.optimizeMovements(robots, stores, path.getLength(), icpcMode);
        
        if (result.getAssignments().isEmpty()) {
            showMessage("No se encontraron movimientos rentables");
            return result;
        }
        
        showMessage("=== Iniciando Optimización de Movimientos ===");
        showMessage("Estrategia: " + result.getStrategy());
        showMessage("Asignaciones encontradas: " + result.getAssignments().size());
        
        // Ejecutar los movimientos optimizados
        double profitBefore = totalProfit;
        int successfulMoves = 0;
        
        for (RobotMovementOptimizer.RobotStoreAssignment assignment : result.getAssignments()) {
            Robot robot = assignment.getRobot();
            Store targetStore = assignment.getStore();
            int targetPosition = icpcMode ? 
                mapICPCPositionToRoute(targetStore.getOriginalPosition()) : 
                targetStore.getPosition();
            
            // Calcular pasos necesarios
            int currentPos = robot.getCurrentPosition();
            int steps = targetPosition - currentPos;
            
            // Ejecutar el movimiento optimizado
            if (moveRobot(robot.getId(), steps)) {
                successfulMoves++;
                showMessage(String.format("✓ Robot %d → Pos %d (ganancia estimada: %d)", 
                    robot.getId(), targetPosition, assignment.getProfit()));
            } else {
                showMessage(String.format("✗ Fallo moviendo Robot %d → Pos %d", 
                    robot.getId(), targetPosition));
            }
        }
        
        double profitGained = totalProfit - profitBefore;
        
        showMessage("=== Resultado de Optimización ===");
        showMessage("Movimientos exitosos: " + successfulMoves + "/" + result.getAssignments().size());
        showMessage("Ganancia obtenida: " + profitGained);
        showMessage("Ganancia esperada: " + result.getTotalProfit());
        showMessage("Eficiencia: " + String.format("%.1f%%", 
            result.getTotalProfit() > 0 ? (profitGained / result.getTotalProfit()) * 100 : 0));
        
        // Actualizar el robot con mayor ganancia para que parpadee
        updateHighestProfitRobot();
        
        return result;
    }
    
    /**
     * Método auxiliar para actualizar el robot con mayor ganancia.
     * Implementa el requisito de usabilidad de parpadeo.
     * NUEVO - Requisito de usabilidad: robot con mayor ganancia parpadea
     */
    private void updateHighestProfitRobot() {
        if (robots.isEmpty()) return;
        
        // Detener parpadeo de todos los robots
        for (Robot robot : robots) {
            robot.stopBlinking();
        }
        
        // Encontrar el robot con mayor ganancia neta
        Robot highestProfitRobot = robots.stream()
            .max(Comparator.comparingInt(Robot::getNetProfit))
            .orElse(null);
        
        if (highestProfitRobot != null && highestProfitRobot.getNetProfit() > 0) {
            highestProfitRobot.startBlinking();
            showMessage("Robot " + highestProfitRobot.getId() + 
                       " tiene la mayor ganancia (" + highestProfitRobot.getNetProfit() + 
                       ") y está parpadeando");
        }
    }
    
    /**
     * Determina la longitud necesaria de la ruta basándose en las posiciones del ICPC.
     * Mapea las posiciones del ICPC a índices de la ruta espiral.
     * 
     * @param icpcInput Entrada del problema ICPC
     * @param suggestedLength Longitud sugerida
     * @return Longitud calculada para la ruta
     */
    private int determineRouteLength(String[] icpcInput, int suggestedLength) {
        if (icpcInput == null || icpcInput.length == 0) {
            return suggestedLength;
        }
        
        Set<Integer> positions = new HashSet<>();
        
        try {
            int n = Integer.parseInt(icpcInput[0]);
            
            for (int i = 1; i <= n; i++) {
                String[] parts = icpcInput[i].trim().split("\\s+");
                if (parts.length >= 2) {
                    int position = Integer.parseInt(parts[1]);
                    positions.add(position);
                }
            }
            
            // Calcular longitud necesaria basándose en el rango de posiciones
            if (!positions.isEmpty()) {
                int maxPos = Collections.max(positions);
                int minPos = Collections.min(positions);
                int range = maxPos - minPos + 1;
                
                // Usar el mayor entre el rango calculado y la longitud sugerida
                return Math.max(range, suggestedLength);
            }
            
        } catch (Exception e) {
            showMessage("Error calculando longitud de ruta: " + e.getMessage());
        }
        
        return suggestedLength;
    }
    
    /**
     * Ejecuta el siguiente día en la secuencia ICPC.
     * NUEVO - Requisito 10: Ejecución por días
     * 
     * @return true si se ejecutó exitosamente, false si no hay más días
     * @throws IllegalStateException si no está en modo ICPC
     */
    public boolean executeNextDay() {
        if (!icpcMode) {
            throw new IllegalStateException("executeNextDay() solo disponible en modo ICPC");
        }
        
        if (!dayManager.hasMoreDays()) {
            showMessage("No hay más días por ejecutar");
            return false;
        }
        
        int dayNumber = dayManager.getCurrentDay();
        showMessage("Ejecutando día " + (dayNumber + 1) + "...");
        
        boolean success = dayManager.executeNextDay(this);
        
        if (success) {
            showMessage("Día " + (dayNumber + 1) + " ejecutado exitosamente");
            showMessage("Ganancia actual: " + totalProfit);
        } else {
            showMessage("Error ejecutando día " + (dayNumber + 1));
        }
        
        return success;
    }
    
    /**
     * Ejecuta todos los días restantes en la secuencia ICPC.
     * NUEVO - Requisito 10: Ejecución completa
     * 
     * @return El número de días ejecutados exitosamente
     * @throws IllegalStateException si no está en modo ICPC
     */
    public int executeAllDays() {
        if (!icpcMode) {
            throw new IllegalStateException("executeAllDays() solo disponible en modo ICPC");
        }
        
        int successfulDays = dayManager.executeAllDays(this);
        showMessage("Ejecutados " + successfulDays + " de " + dayManager.getTotalDays() + " días");
        
        return successfulDays;
    }
    
    /**
     * Obtiene información sobre el estado de los días ICPC.
     * NUEVO - Requisito 10: Consulta de estado
     * 
     * @return String con información de los días
     */
    public String getDaysInfo() {
        if (!icpcMode) {
            return "No está en modo ICPC";
        }
        
        StringBuilder info = new StringBuilder();
        info.append("=== Información de Días ICPC ===\n");
        info.append("Días totales: ").append(dayManager.getTotalDays()).append("\n");
        info.append("Día actual: ").append(dayManager.getCurrentDay() + 1).append("\n");
        info.append("Días restantes: ").append(dayManager.getTotalDays() - dayManager.getCurrentDay()).append("\n");
        
        if (dayManager.hasMoreDays()) {
            info.append("Estado: En progreso\n");
        } else {
            info.append("Estado: Completado\n");
        }
        
        return info.toString();
    }
    
    /**
     * Reinicia la secuencia de días al inicio.
     * NUEVO - Requisito 10: Reset de secuencia
     */
    public void resetDaySequence() {
        if (icpcMode) {
            dayManager.reset();
            showMessage("Secuencia de días reiniciada");
        }
    }
    
    /**
     * Mapea una posición del problema ICPC a un índice de la ruta espiral.
     * Permite manejar posiciones arbitrarias del ICPC en nuestra ruta fija.
     * 
     * @param icpcPosition Posición del problema ICPC
     * @return Índice mapeado en la ruta espiral
     */
    private int mapICPCPositionToRoute(int icpcPosition) {
        if (path == null) {
            return 0;
        }
        
        // Mapeo simple: usar módulo para "enrollar" posiciones grandes en la ruta
        // Esto permite que posiciones del ICPC como 20, 50, 80 se mapeen a índices 0-N
        return Math.abs(icpcPosition) % path.getLength();
    }
    
    // Métodos extendidos para soporte ICPC
    
    /**
     * Añade una tienda con soporte para posiciones ICPC.
     * EXTENSIÓN del método original para soportar mapeo de posiciones
     * 
     * @param position La posición donde ubicar la tienda (ICPC o tradicional)
     * @param tenges La cantidad inicial de tenges en la tienda
     * @return true si se pudo añadir la tienda, false en caso contrario
     */
    public boolean addStore(int position, int tenges) {
        int mappedPosition = icpcMode ? mapICPCPositionToRoute(position) : position;
        
        if (path == null) {
            showMessage("Error: La ruta no ha sido creada aún");
            return false;
        }
        
        if (mappedPosition < 0 || mappedPosition >= path.getLength()) {
            showMessage("Error: Posición fuera de los límites de la ruta");
            return false;
        }
        
        // Verificar si la posición está ocupada por una tienda
        for (Store store : stores) {
            int storePos = icpcMode ? mapICPCPositionToRoute(store.getOriginalPosition()) : store.getPosition();
            if (storePos == mappedPosition) {
                showMessage("Error: Ya existe una tienda en la posición " + position);
                return false;
            }
        }
        
        // Verificar si hay un robot con posición inicial ahí
        for (Robot robot : robots) {
            int robotPos = icpcMode ? mapICPCPositionToRoute(robot.getOriginalInitialPosition()) : robot.getInitialPosition();
            if (robotPos == mappedPosition) {
                showMessage("Error: Hay un robot con posición inicial en " + position);
                return false;
            }
        }
        
        // Crear y añadir la tienda
        Store newStore = new Store(mappedPosition, tenges);
        if (icpcMode) {
            newStore.setOriginalPosition(position); // Guardar posición original del ICPC
        }
        stores.add(newStore);
        
        // Posicionar visualmente la tienda usando las coordenadas del segmento
        PathSegment segment = path.getSegment(mappedPosition);
        int[] visualCoords = segment.getCenteredCoordinates();
        newStore.setPosition(visualCoords[0], visualCoords[1]);
        
        if (isVisible) {
            newStore.makeVisible();
        }
        
        // Actualizar ganancia máxima posible y barra de progreso
        maxPossibleProfit += tenges;
        updateProgressBar();
        
        String positionStr = icpcMode ? position + " (mapeada a " + mappedPosition + ")" : String.valueOf(position);
        showMessage("Tienda añadida en posición " + positionStr + " con " + tenges + " tenges");
        return true;
    }
    
    /**
     * Añade un robot con soporte para posiciones ICPC.
     * EXTENSIÓN del método original para soportar mapeo de posiciones
     * 
     * @param initialPosition La posición inicial del robot (ICPC o tradicional)
     * @return El ID del robot creado, o -1 si no se pudo crear
     */
    public int addRobot(int initialPosition) {
        int mappedPosition = icpcMode ? mapICPCPositionToRoute(initialPosition) : initialPosition;
        
        if (path == null) {
            showMessage("Error: La ruta no ha sido creada aún");
            return -1;
        }
        
        if (mappedPosition < 0 || mappedPosition >= path.getLength()) {
            showMessage("Error: Posición fuera de los límites de la ruta");
            return -1;
        }
        
        // Verificar si ya hay un robot con esa posición inicial
        for (Robot robot : robots) {
            int robotPos = icpcMode ? mapICPCPositionToRoute(robot.getOriginalInitialPosition()) : robot.getInitialPosition();
            if (robotPos == mappedPosition) {
                showMessage("Error: Ya existe un robot con posición inicial en " + initialPosition);
                return -1;
            }
        }
        
        // Verificar si hay una tienda en esa posición
        for (Store store : stores) {
            int storePos = icpcMode ? mapICPCPositionToRoute(store.getOriginalPosition()) : store.getPosition();
            if (storePos == mappedPosition) {
                showMessage("Error: Hay una tienda en la posición " + initialPosition);
                return -1;
            }
        }
        
        // Crear y añadir el robot
        Robot newRobot = new Robot(mappedPosition, 1000);
        if (icpcMode) {
            newRobot.setOriginalInitialPosition(initialPosition); // Guardar posición original del ICPC
        }
        robots.add(newRobot);
        
        // Posicionar visualmente el robot
        PathSegment segment = path.getSegment(mappedPosition);
        int[] visualCoords = segment.getCenteredCoordinates();
        newRobot.setVisualPosition(visualCoords[0] + 5, visualCoords[1] - 5);
        
        if (isVisible) {
            newRobot.makeVisible();
        }
        
        String positionStr = icpcMode ? initialPosition + " (mapeada a " + mappedPosition + ")" : String.valueOf(initialPosition);
        showMessage("Robot añadido con ID " + newRobot.getId() + " en posición " + positionStr);
        return newRobot.getId();
    }
    
    // Métodos del ciclo anterior que se mantienen sin cambios...
    
    /**
     * Elimina una tienda de la posición especificada.
     * Requisito 2: remove store
     */
    public boolean removeStore(int position) {
        int mappedPosition = icpcMode ? mapICPCPositionToRoute(position) : position;
        Store storeToRemove = null;
        
        for (Store store : stores) {
            int storePos = icpcMode ? mapICPCPositionToRoute(store.getOriginalPosition()) : store.getPosition();
            if (storePos == mappedPosition) {
                storeToRemove = store;
                break;
            }
        }
        
        if (storeToRemove != null) {
            storeToRemove.makeInvisible();
            stores.remove(storeToRemove);
            maxPossibleProfit -= storeToRemove.getInitialTenges();
            updateProgressBar();
            showMessage("Tienda eliminada de la posición " + position);
            return true;
        }
        
        showMessage("Error: No hay tienda en la posición " + position);
        return false;
    }
    
    /**
     * Reabastece todas las tiendas con su inventario inicial.
     * Requisito 2: resupply stores
     */
    public void resupplyStores() {
        for (Store store : stores) {
            store.resupply();
            if (isVisible) {
                store.makeVisible();
            }
        }
        
        recalculateMaxProfit();
        updateProgressBar();
        showMessage("Todas las tiendas han sido reabastecidas");
    }
    
    /**
     * Elimina un robot específico.
     * Requisito 3: delete robot
     */
    public boolean deleteRobot(int robotId) {
        Robot robotToRemove = null;
        
        for (Robot robot : robots) {
            if (robot.getId() == robotId) {
                robotToRemove = robot;
                break;
            }
        }
        
        if (robotToRemove != null) {
            robotToRemove.makeInvisible();
            robots.remove(robotToRemove);
            recalculateTotalProfit();
            updateProgressBar();
            showMessage("Robot " + robotId + " eliminado");
            return true;
        }
        
        showMessage("Error: No se encontró robot con ID " + robotId);
        return false;
    }
    
    /**
     * Retorna todos los robots a sus posiciones iniciales.
     * Requisito 3: return robots
     */
    public void returnRobots() {
        for (Robot robot : robots) {
            robot.returnToInitialPosition();
            robot.setCostIncurred(0);
            robot.resetTengesCollected();
            
            int visualPosition = icpcMode ? mapICPCPositionToRoute(robot.getOriginalInitialPosition()) : robot.getInitialPosition();
            PathSegment segment = path.getSegment(visualPosition);
            int[] visualCoords = segment.getCenteredCoordinates();
            robot.setVisualPosition(visualCoords[0] + 5, visualCoords[1] - 5);
        }
        
        recalculateTotalProfit();
        updateProgressBar();
        showMessage("Todos los robots han sido retornados a sus posiciones iniciales");
    }
    
    /**
     * Mueve un robot específico.
     * Requisito 4: move robot
     */
    public boolean moveRobot(int robotId, int steps) {
        Robot robot = null;
        
        for (Robot r : robots) {
            if (r.getId() == robotId) {
                robot = r;
                break;
            }
        }
        
        if (robot == null) {
            showMessage("Error: No se encontró robot con ID " + robotId);
            return false;
        }
        
        int currentPos = robot.getCurrentPosition();
        int newPos = currentPos + steps;
        
        if (newPos < 0) {
            newPos = 0;
            steps = newPos - currentPos;
        } else if (newPos >= path.getLength()) {
            newPos = path.getLength() - 1;
            steps = newPos - currentPos;
        }
        
        int movementCost = Math.abs(steps);
        robot.addCost(movementCost);
        robot.moveTo(newPos);
        
        PathSegment segment = path.getSegment(newPos);
        int[] visualCoords = segment.getCenteredCoordinates();
        robot.setVisualPosition(visualCoords[0] + 5, visualCoords[1] - 5);
        
        for (Store store : stores) {
            int storePos = icpcMode ? mapICPCPositionToRoute(store.getOriginalPosition()) : store.getPosition();
            if (storePos == newPos && store.getTenges() > 0) {
                int collected = store.collectAll();
                robot.collectTenges(collected);
                
                int profit = collected - movementCost;
                totalProfit += profit;
                updateProgressBar();
                
                showMessage("Robot " + robotId + " recogió " + collected + 
                           " tenges en posición " + newPos + 
                           ". Costo: " + movementCost + 
                           ", Ganancia neta: " + profit);
                return true;
            }
        }
        
        totalProfit -= movementCost;
        updateProgressBar();
        
        showMessage("Robot " + robotId + " se movió a posición " + newPos + 
                   ". Costo: " + movementCost);
        return true;
    }
    
    /**
     * Reinicia la ruta de seda.
     * Requisito 5: reboot
     */
    public void reboot() {
        resupplyStores();
        returnRobots();
        totalProfit = 0.0;
        recalculateMaxProfit();
        updateProgressBar();
        showMessage("Simulador reiniciado (reboot)");
    }
    
    /**
     * Consulta las ganancias obtenidas.
     * Requisito 6: consult profit
     */
    public double getProfit() {
        return totalProfit;
    }
    
    /**
     * Consulta la información de la ruta de seda.
     * Requisito 7: consult silk road
     */
    public String getInfo() {
        StringBuilder info = new StringBuilder();
        info.append("=== Información de la Ruta de Seda ===\n");
        
        if (path != null) {
            info.append("Modo: ").append(icpcMode ? "ICPC" : "Tradicional").append("\n");
            info.append("Longitud de la ruta: ").append(path.getLength()).append(" segmentos\n");
            
            if (icpcMode) {
                info.append(getDaysInfo()).append("\n");
            }
            
            info.append("Número de tiendas: ").append(stores.size()).append("\n");
            
            for (Store store : stores) {
                String posStr = icpcMode ? 
                    store.getOriginalPosition() + " (→" + store.getPosition() + ")" : 
                    String.valueOf(store.getPosition());
                info.append("  - Tienda en pos ").append(posStr)
                    .append(": ").append(store.getTenges()).append("/")
                    .append(store.getInitialTenges()).append(" tenges\n");
            }
            
            info.append("Número de robots: ").append(robots.size()).append("\n");
            
            for (Robot robot : robots) {
                info.append("  - ").append(robot.getInfo()).append("\n");
            }
            
            info.append("Ganancia actual: ").append(totalProfit).append("\n");
            info.append("Ganancia máxima posible: ").append(maxPossibleProfit).append("\n");
            info.append(progressBar.getStatusInfo()).append("\n");
        } else {
            info.append("La ruta no ha sido creada aún.\n");
        }
        
        return info.toString();
    }
    
    /**
     * Hace visible el simulador.
     * Requisito 8: make visible
     */
    public void makeVisible() {
        isVisible = true;
        
        if (path != null) {
            path.makeVisible();
            progressBar.makeVisible();
            
            for (Store store : stores) {
                store.makeVisible();
            }
            
            for (Robot robot : robots) {
                robot.makeVisible();
            }
        }
    }
    
    /**
     * Hace invisible el simulador.
     * Requisito 8: make invisible
     */
    public void makeInvisible() {
        isVisible = false;
        
        if (path != null) {
            path.makeInvisible();
            progressBar.makeInvisible();
            
            for (Store store : stores) {
                store.makeInvisible();
            }
            
            for (Robot robot : robots) {
                robot.makeInvisible();
            }
        }
    }
    
    /**
     * Termina el simulador.
     * Requisito 9: finish
     */
    public void finish() {
        makeInvisible();
        stores.clear();
        robots.clear();
        path = null;
        totalProfit = 0.0;
        maxPossibleProfit = 0.0;
        dayManager = new DayManager();
        icpcMode = false;
        showMessage("Simulador terminado");
    }
    
    /**
     * Verifica si el simulador está visible.
     */
    public boolean isVisible() {
        return isVisible;
    }
    
    /**
     * Verifica si está en modo ICPC.
     * NUEVO - Requisito 10
     */
    public boolean isICPCMode() {
        return icpcMode;
    }
    
    // Métodos auxiliares
    
    private void updateProgressBar() {
        if (progressBar != null) {
            progressBar.updateProgress(totalProfit, maxPossibleProfit);
        }
    }
    
    private void recalculateMaxProfit() {
        maxPossibleProfit = 0.0;
        for (Store store : stores) {
            maxPossibleProfit += store.getInitialTenges();
        }
    }
    
    private void recalculateTotalProfit() {
        totalProfit = 0.0;
        for (Robot robot : robots) {
            totalProfit += robot.getNetProfit();
        }
    }
    
    public ProfitProgressBar getProgressBar() {
        return progressBar;
    }
    
    public void setProgressBarPosition(int x, int y) {
        if (progressBar != null) {
            progressBar.setPosition(x, y);
        }
    }
    
    public double getProgressPercentage() {
        return progressBar != null ? progressBar.getProgressPercentage() : 0.0;
    }
    
    private void showMessage(String message) {
        if (isVisible) {
            System.out.println("[SilkRoad] " + message);
        }
    }
}