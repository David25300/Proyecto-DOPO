/**
 * Barra de progreso visual para mostrar las ganancias del simulador.
 * Muestra la ganancia actual como un porcentaje de la ganancia máxima posible.
 * 
 * Principios aplicados:
 * - Responsabilidad Única: Solo maneja la visualización de la barra de progreso
 * - Abierto/Cerrado: Extensible para diferentes tipos de barras
 * - Bajo acoplamiento: No depende de la implementación específica del simulador
 * 
 * @author Tu Nombre
 * @version 1.0
 */
public class ProfitProgressBar {
    
    private Rectangle background;
    private Rectangle progressBar;
    private Rectangle border;
    
    private int x;
    private int y;
    private int totalWidth;
    private int height;
    private double currentProfit;
    private double maxProfit;
    private boolean isVisible;
    
    private static final String BACKGROUND_COLOR = "white";
    private static final String PROGRESS_COLOR = "green";
    private static final String BORDER_COLOR = "black";
    private static final int BORDER_WIDTH = 2;
    
    /**
     * Constructor de la barra de progreso.
     * 
     * @param x Coordenada x de la esquina superior izquierda
     * @param y Coordenada y de la esquina superior izquierda
     * @param width Ancho total de la barra
     * @param height Alto de la barra
     */
    public ProfitProgressBar(int x, int y, int width, int height) {
        this.x = x;
        this.y = y;
        this.totalWidth = width;
        this.height = height;
        this.currentProfit = 0.0;
        this.maxProfit = 1.0; // Valor por defecto para evitar división por cero
        this.isVisible = false;
        
        initializeComponents();
    }
    
    /**
     * Inicializa los componentes visuales de la barra.
     * Aplicando el principio de separación de responsabilidades.
     */
    private void initializeComponents() {
        // Crear el fondo de la barra
        background = new Rectangle();
        background.changeSize(height, totalWidth);
        background.changeColor(BACKGROUND_COLOR);
        
        // Crear la barra de progreso
        progressBar = new Rectangle();
        progressBar.changeSize(height - (BORDER_WIDTH * 2), 0); // Inicialmente sin ancho
        progressBar.changeColor(PROGRESS_COLOR);
        
        // Crear el borde
        border = new Rectangle();
        border.changeSize(height, totalWidth);
        border.changeColor(BORDER_COLOR);
        
        // Posicionar los elementos
        positionComponents();
    }
    
    /**
     * Posiciona todos los componentes en sus coordenadas correctas.
     * Principio DRY: centraliza la lógica de posicionamiento.
     */
    private void positionComponents() {
        // Posicionar el borde (base)
        int borderDeltaX = x - 70; // Posición por defecto de Rectangle
        int borderDeltaY = y - 15;
        
        if (borderDeltaX != 0) {
            border.moveHorizontal(borderDeltaX);
        }
        if (borderDeltaY != 0) {
            border.moveVertical(borderDeltaY);
        }
        
        // Posicionar el fondo (ligeramente dentro del borde)
        background = new Rectangle();
        background.changeSize(height - (BORDER_WIDTH * 2), totalWidth - (BORDER_WIDTH * 2));
        background.changeColor(BACKGROUND_COLOR);
        
        int backgroundDeltaX = (x + BORDER_WIDTH) - 70;
        int backgroundDeltaY = (y + BORDER_WIDTH) - 15;
        
        if (backgroundDeltaX != 0) {
            background.moveHorizontal(backgroundDeltaX);
        }
        if (backgroundDeltaY != 0) {
            background.moveVertical(backgroundDeltaY);
        }
        
        // Posicionar la barra de progreso
        updateProgressBar();
    }
    
    /**
     * Actualiza la barra de progreso basándose en los valores actuales.
     * Principio de Responsabilidad Única: solo actualiza la visualización.
     */
    private void updateProgressBar() {
        if (progressBar != null) {
            progressBar.makeInvisible();
        }
        
        // Calcular el ancho de la barra basándose en el porcentaje
        double percentage = maxProfit > 0 ? currentProfit / maxProfit : 0;
        percentage = Math.max(0, Math.min(1, percentage)); // Clamp entre 0 y 1
        
        int progressWidth = (int) (percentage * (totalWidth - (BORDER_WIDTH * 2)));
        
        if (progressWidth > 0) {
            progressBar = new Rectangle();
            progressBar.changeSize(height - (BORDER_WIDTH * 2), progressWidth);
            
            // Cambiar color según el progreso (extensibilidad)
            String color = getProgressColor(percentage);
            progressBar.changeColor(color);
            
            // Posicionar la barra de progreso
            int progressDeltaX = (x + BORDER_WIDTH) - 70;
            int progressDeltaY = (y + BORDER_WIDTH) - 15;
            
            if (progressDeltaX != 0) {
                progressBar.moveHorizontal(progressDeltaX);
            }
            if (progressDeltaY != 0) {
                progressBar.moveVertical(progressDeltaY);
            }
            
            if (isVisible) {
                progressBar.makeVisible();
            }
        }
    }
    
    /**
     * Determina el color de la barra basándose en el porcentaje de progreso.
     * Extensible: permite agregar más rangos de colores fácilmente.
     * 
     * @param percentage El porcentaje de progreso (0.0 a 1.0)
     * @return El color apropiado para la barra
     */
    private String getProgressColor(double percentage) {
        if (percentage >= 0.8) {
            return "green";    // Excelente progreso
        } else if (percentage >= 0.5) {
            return "yellow";   // Progreso moderado
        } else if (percentage >= 0.2) {
            return "orange";   // Progreso bajo
        } else {
            return "red";      // Progreso muy bajo
        }
    }
    
    /**
     * Actualiza los valores de ganancia y refresca la visualización.
     * Interface pública para el simulador.
     * 
     * @param currentProfit Ganancia actual
     * @param maxProfit Ganancia máxima posible
     */
    public void updateProgress(double currentProfit, double maxProfit) {
        this.currentProfit = currentProfit;
        this.maxProfit = Math.max(maxProfit, 1.0); // Prevenir división por cero
        
        if (isVisible) {
            updateProgressBar();
        }
    }
    
    /**
     * Hace visible la barra de progreso.
     */
    public void makeVisible() {
        isVisible = true;
        border.makeVisible();
        background.makeVisible();
        updateProgressBar(); // Esto hará visible la barra de progreso si tiene contenido
    }
    
    /**
     * Hace invisible la barra de progreso.
     */
    public void makeInvisible() {
        isVisible = false;
        border.makeInvisible();
        background.makeInvisible();
        if (progressBar != null) {
            progressBar.makeInvisible();
        }
    }
    
    /**
     * Obtiene el porcentaje actual de progreso.
     * 
     * @return Porcentaje como double entre 0.0 y 1.0
     */
    public double getProgressPercentage() {
        return maxProfit > 0 ? Math.max(0, Math.min(1, currentProfit / maxProfit)) : 0;
    }
    
    /**
     * Verifica si la barra está visible.
     * 
     * @return true si está visible, false en caso contrario
     */
    public boolean isVisible() {
        return isVisible;
    }
    
    /**
     * Cambia la posición de la barra de progreso.
     * Útil para reposicionar dinámicamente.
     * 
     * @param newX Nueva coordenada x
     * @param newY Nueva coordenada y
     */
    public void setPosition(int newX, int newY) {
        boolean wasVisible = isVisible;
        
        if (wasVisible) {
            makeInvisible();
        }
        
        this.x = newX;
        this.y = newY;
        
        positionComponents();
        
        if (wasVisible) {
            makeVisible();
        }
    }
    
    /**
     * Obtiene información de estado de la barra.
     * Útil para debugging y testing.
     * 
     * @return String con información del estado
     */
    public String getStatusInfo() {
        double percentage = getProgressPercentage();
        return String.format("Progress Bar: %.1f%% (%.2f/%.2f)", 
                           percentage * 100, currentProfit, maxProfit);
    }
}